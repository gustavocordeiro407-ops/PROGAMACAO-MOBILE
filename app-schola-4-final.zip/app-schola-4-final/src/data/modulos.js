const modulos = {

  aluno: {
    titulo: 'Alunos',
    singular: 'Aluno',
  },

  professor: {
    titulo: 'Professores',
    singular: 'Professor',
  },

  curso: {
    titulo: 'Cursos',
    singular: 'Curso',
  },

  disciplina: {
    titulo: 'Disciplinas',
    singular: 'Disciplina',
  },

  responsavel: {
    titulo: 'Responsáveis',
    singular: 'Responsável',
  },

  matricula: {
    titulo: 'Matrículas',
    singular: 'Matrícula',
  },

  turma: {
    titulo: 'Turmas',
    singular: 'Turma',
  },

  avaliacao: {
    titulo: 'Avaliações',
    singular: 'Avaliação',
  },

  coordenador: {
    titulo: 'Coordenadores',
    singular: 'Coordenador',
  },

  boletim: {
    titulo: 'Boletins',
    singular: 'Boletim',
  },

};

export default modulos;