import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  containerHome: {
    flexGrow: 1,
    backgroundColor: '#f2f2f2',
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 40,
  },

  containerSobre: {
    flexGrow: 1,
    backgroundColor: '#f2f2f2',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 25,
  },

  logo: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },

  logoSobre: {
    width: 120,
    height: 120,
    marginBottom: 20,
  },

  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#1565C0',
    textAlign: 'center',
  },

  subtitulo: {
    fontSize: 18,
    marginBottom: 40,
    marginTop: 10,
    color: '#666',
    textAlign: 'center',
  },

  subtituloHome: {
    fontSize: 18,
    marginBottom: 30,
    color: '#666',
    textAlign: 'center',
  },

  subtituloSobre: {
    fontSize: 18,
    color: '#666',
    marginTop: 5,
    marginBottom: 30,
    textAlign: 'center',
  },

  botao: {
    width: '80%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    alignItems: 'center',
  },

  botaoVoltar: {
    width: '80%',
    backgroundColor: '#555',
    padding: 15,
    borderRadius: 10,
    marginTop: 10,
    alignItems: 'center',
  },

  botaoSobre: {
    width: '80%',
    backgroundColor: '#555',
    padding: 15,
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 15,
    alignItems: 'center',
  },

  textoBotao: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#FFFFFF',
  },

  caixaSobre: {
    width: '90%',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginBottom: 25,
  },

  textoSobre: {
    fontSize: 16,
    color: '#444',
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 15,
  },

  containerFormulario: {
    flexGrow: 1,
    backgroundColor: '#f2f2f2',
    alignItems: 'center',
    paddingTop: 40,
    paddingBottom: 40,
    paddingHorizontal: 20,
  },

  subtituloFormulario: {
    fontSize: 18,
    color: '#666',
    marginTop: 5,
    marginBottom: 30,
    textAlign: 'center',
  },

  caixaFormulario: {
    width: '90%',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginBottom: 20,
  },

  tituloSecaoFormulario: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1565C0',
    marginBottom: 20,
  },

  label: {
    width: '80%',
    fontSize: 16,
    fontWeight: 'bold',
    color: '#444',
    marginBottom: 5,
  },

  input: {
    width: '80%',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#CCC',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    marginBottom: 15,
  },

  caixaResultado: {
    width: '90%',
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    marginTop: 10,
    marginBottom: 20,
  },

  tituloResultado: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#1565C0',
    marginBottom: 15,
    textAlign: 'center',
  },

  tituloSecao: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1565C0',
    marginTop: 20,
    marginBottom: 10,
  },

  textoResultado: {
    fontSize: 16,
    color: '#444',
    marginBottom: 8,
  },

  consultaContainer: {
    flex: 1,
    backgroundColor: '#f2f2f2',
    padding: 20,
    alignItems: 'center',
  },

  textoAjuda: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginTop: 5,
    marginBottom: 20,
  },

  pesquisaLinha: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#DDD',
    borderRadius: 10,
    paddingHorizontal: 12,
    marginBottom: 12,
  },

  inputPesquisa: {
    flex: 1,
    padding: 12,
    fontSize: 15,
  },

  botaoNovoAluno: {
    width: '100%',
    backgroundColor: '#1976D2',
    padding: 13,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 15,
  },

  textoNovoAluno: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 5,
  },

  listaAlunos: {
    width: '100%',
    flex: 1,
  },

  cardAluno: {
    width: '100%',
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },

  alunoInfo: {
    flex: 1,
  },

  nomeAluno: {
    fontSize: 17,
    fontWeight: 'bold',
    color: '#222',
    marginBottom: 5,
  },

  detalheAluno: {
    fontSize: 14,
    color: '#666',
    marginBottom: 3,
  },

  acoesAluno: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  botaoAcao: {
    padding: 8,
  },

  listaVazia: {
    textAlign: 'center',
    color: '#777',
    fontSize: 16,
    marginTop: 40,
  },

  linhaBotoes: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },

  botaoCancelar: {
    width: '47%',
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#1976D2',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },

  botaoSalvar: {
    width: '47%',
    backgroundColor: '#1976D2',
    padding: 15,
    borderRadius: 10,
    alignItems: 'center',
  },

  textoCancelar: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1976D2',
  },


  homeNovaContainer: {
  flexGrow: 1,
  backgroundColor: '#F6F7F9',
  paddingHorizontal: 20,
  paddingTop: 24,
  paddingBottom: 45,
},

homeCabecalho: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 35,
},

homeMarcaLinha: {
  flexDirection: 'row',
  alignItems: 'center',
},

homeLogoNova: {
  width: 46,
  height: 46,
  borderRadius: 14,
  backgroundColor: '#EAF1FF',
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: 12,
},

homeMarca: {
  fontSize: 18,
  fontWeight: '700',
  color: '#171717',
},

homeMarcaSub: {
  fontSize: 13,
  color: '#858A94',
  marginTop: 2,
},

homeInfoBotao: {
  width: 42,
  height: 42,
  borderRadius: 14,
  backgroundColor: '#FFFFFF',
  borderWidth: 1,
  borderColor: '#E7E8EB',
  justifyContent: 'center',
  alignItems: 'center',
},

homeApresentacao: {
  marginBottom: 35,
},

homePequenoTitulo: {
  fontSize: 12,
  fontWeight: '700',
  color: '#2563EB',
  letterSpacing: 1.2,
  marginBottom: 10,
},

homeTituloNovo: {
  fontSize: 34,
  lineHeight: 40,
  fontWeight: '700',
  color: '#171717',
  letterSpacing: -1,
},

homeDescricaoNova: {
  fontSize: 15,
  lineHeight: 22,
  color: '#737780',
  marginTop: 14,
  maxWidth: 360,
},

homeTituloSecao: {
  fontSize: 18,
  fontWeight: '700',
  color: '#252525',
  marginBottom: 14,
},

homeGrid: {
  width: '100%',
  flexDirection: 'row',
  flexWrap: 'wrap',
  justifyContent: 'space-between',
  marginBottom: 26,
},

homeCard: {
  width: '48.3%',
  minHeight: 150,
  backgroundColor: '#FFFFFF',
  borderRadius: 20,
  borderWidth: 1,
  borderColor: '#E7E8EB',
  padding: 16,
  marginBottom: 12,
},

homeCardTopo: {
  flexDirection: 'row',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: 24,
},

homeCardIcone: {
  width: 42,
  height: 42,
  borderRadius: 13,
  backgroundColor: '#EEF4FF',
  justifyContent: 'center',
  alignItems: 'center',
},

homeCardTitulo: {
  fontSize: 17,
  fontWeight: '700',
  color: '#202020',
  marginBottom: 5,
},

homeCardDescricao: {
  fontSize: 12,
  lineHeight: 17,
  color: '#858A94',
},

homeLista: {
  width: '100%',
  backgroundColor: '#FFFFFF',
  borderRadius: 20,
  borderWidth: 1,
  borderColor: '#E7E8EB',
  overflow: 'hidden',
},

homeListaItem: {
  minHeight: 64,
  paddingHorizontal: 16,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
},

homeListaItemBorda: {
  borderBottomWidth: 1,
  borderBottomColor: '#EFEFF1',
},

homeListaEsquerda: {
  flexDirection: 'row',
  alignItems: 'center',
},

homeListaIcone: {
  width: 38,
  height: 38,
  borderRadius: 12,
  backgroundColor: '#F3F4F6',
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: 13,
},

homeListaTexto: {
  fontSize: 15,
  fontWeight: '600',
  color: '#343434',
},

homeRodape: {
  textAlign: 'center',
  fontSize: 12,
  color: '#A0A4AC',
  marginTop: 28,
},


alunoNovaContainer: {
  flex: 1,
  backgroundColor: '#F6F7F9',
  paddingHorizontal: 20,
  paddingTop: 24,
},

alunoCabecalhoNovo: {
  marginBottom: 24,
},

alunoPequenoTitulo: {
  fontSize: 12,
  fontWeight: '700',
  color: '#2563EB',
  letterSpacing: 1.2,
  marginBottom: 7,
},

alunoTituloNovo: {
  fontSize: 32,
  fontWeight: '700',
  color: '#171717',
  letterSpacing: -0.8,
},

alunoDescricaoNova: {
  fontSize: 14,
  lineHeight: 21,
  color: '#737780',
  marginTop: 8,
},

alunoPesquisaNova: {
  width: '100%',
  minHeight: 52,
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#FFFFFF',
  borderWidth: 1,
  borderColor: '#E5E7EB',
  borderRadius: 16,
  paddingHorizontal: 15,
  marginBottom: 12,
},

alunoPesquisaInput: {
  flex: 1,
  fontSize: 15,
  color: '#222222',
  paddingVertical: 14,
  paddingHorizontal: 10,
  outlineStyle: 'none',
},

alunoNovoBotao: {
  width: '100%',
  minHeight: 50,
  backgroundColor: '#2563EB',
  borderRadius: 15,
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: 26,
},

alunoNovoBotaoTexto: {
  color: '#FFFFFF',
  fontSize: 15,
  fontWeight: '700',
  marginLeft: 7,
},

alunoContagemLinha: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 12,
},

alunoContagemTitulo: {
  fontSize: 17,
  fontWeight: '700',
  color: '#282828',
},

alunoContagemBadge: {
  minWidth: 28,
  height: 28,
  borderRadius: 14,
  backgroundColor: '#EAF1FF',
  justifyContent: 'center',
  alignItems: 'center',
  marginLeft: 9,
  paddingHorizontal: 8,
},

alunoContagemNumero: {
  fontSize: 12,
  fontWeight: '700',
  color: '#2563EB',
},

alunoListaNova: {
  width: '100%',
  flex: 1,
},

alunoNovoCard: {
  width: '100%',
  minHeight: 105,
  backgroundColor: '#FFFFFF',
  borderWidth: 1,
  borderColor: '#E7E8EB',
  borderRadius: 18,
  padding: 15,
  marginBottom: 11,
  flexDirection: 'row',
  alignItems: 'center',
},

alunoAvatar: {
  width: 48,
  height: 48,
  borderRadius: 15,
  backgroundColor: '#EEF4FF',
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: 13,
},

alunoAvatarTexto: {
  fontSize: 15,
  fontWeight: '700',
  color: '#2563EB',
},

alunoCardConteudo: {
  flex: 1,
  paddingRight: 8,
},

alunoNomeNovo: {
  fontSize: 16,
  fontWeight: '700',
  color: '#222222',
  marginBottom: 4,
},

alunoCursoNovo: {
  fontSize: 13,
  color: '#737780',
  marginBottom: 9,
},

alunoMetaLinha: {
  flexDirection: 'row',
  alignItems: 'center',
},

alunoMetaItem: {
  flexDirection: 'row',
  alignItems: 'center',
},

alunoMetaTexto: {
  fontSize: 12,
  color: '#8A8F98',
  marginLeft: 4,
},

alunoMetaPonto: {
  width: 3,
  height: 3,
  borderRadius: 2,
  backgroundColor: '#C3C6CB',
  marginHorizontal: 8,
},

alunoAcoesNovas: {
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
},

alunoBotaoEditar: {
  width: 36,
  height: 36,
  borderRadius: 11,
  backgroundColor: '#EEF4FF',
  justifyContent: 'center',
  alignItems: 'center',
  marginBottom: 6,
},

alunoBotaoExcluir: {
  width: 36,
  height: 36,
  borderRadius: 11,
  backgroundColor: '#FEF2F2',
  justifyContent: 'center',
  alignItems: 'center',
},

alunoListaVazia: {
  alignItems: 'center',
  justifyContent: 'center',
  paddingVertical: 55,
  paddingHorizontal: 25,
},

alunoListaVaziaIcone: {
  width: 58,
  height: 58,
  borderRadius: 18,
  backgroundColor: '#ECEEF1',
  justifyContent: 'center',
  alignItems: 'center',
  marginBottom: 15,
},

alunoListaVaziaTitulo: {
  fontSize: 16,
  fontWeight: '700',
  color: '#303030',
  marginBottom: 6,
},

alunoListaVaziaTexto: {
  fontSize: 13,
  lineHeight: 19,
  color: '#858A94',
  textAlign: 'center',
},

formNovaContainer: {
  flexGrow: 1,
  backgroundColor: '#F6F7F9',
  paddingHorizontal: 20,
  paddingTop: 24,
  paddingBottom: 45,
},

formCabecalho: {
  marginBottom: 30,
},

formPequenoTitulo: {
  fontSize: 12,
  fontWeight: '700',
  color: '#2563EB',
  letterSpacing: 1.2,
  marginBottom: 7,
},

formTitulo: {
  fontSize: 32,
  fontWeight: '700',
  color: '#171717',
  letterSpacing: -0.8,
},

formDescricao: {
  fontSize: 14,
  lineHeight: 21,
  color: '#737780',
  marginTop: 8,
},

formTituloSecao: {
  fontSize: 15,
  fontWeight: '700',
  color: '#343434',
  marginBottom: 10,
  marginTop: 5,
},

formCard: {
  width: '100%',
  backgroundColor: '#FFFFFF',
  borderWidth: 1,
  borderColor: '#E7E8EB',
  borderRadius: 18,
  overflow: 'hidden',
  marginBottom: 24,
},

formCampo: {
  paddingHorizontal: 16,
  paddingTop: 15,
  paddingBottom: 12,
},

formLabelLinha: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 5,
},

formLabel: {
  fontSize: 12,
  fontWeight: '600',
  color: '#737780',
  marginLeft: 7,
},

formInput: {
  width: '100%',
  fontSize: 16,
  fontWeight: '500',
  color: '#222222',
  paddingVertical: 7,
  paddingHorizontal: 0,
  backgroundColor: 'transparent',
},

formDivisor: {
  height: 1,
  backgroundColor: '#EFEFF1',
  marginLeft: 16,
},

formBotoesLinha: {
  width: '100%',
  flexDirection: 'row',
  justifyContent: 'space-between',
  marginTop: 3,
},

formBotaoSecundario: {
  width: '38%',
  height: 52,
  borderRadius: 15,
  borderWidth: 1,
  borderColor: '#DADCE0',
  backgroundColor: '#FFFFFF',
  alignItems: 'center',
  justifyContent: 'center',
},

formBotaoSecundarioTexto: {
  fontSize: 15,
  fontWeight: '700',
  color: '#525866',
},

formBotaoPrincipal: {
  flex: 1,
  height: 52,
  borderRadius: 15,
  backgroundColor: '#2563EB',
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'center',
  marginLeft: 10,
},

formBotaoPrincipalTexto: {
  fontSize: 15,
  fontWeight: '700',
  color: '#FFFFFF',
  marginLeft: 6,
},

formErroContainer: {
  flex: 1,
  backgroundColor: '#F6F7F9',
  justifyContent: 'center',
  alignItems: 'center',
  padding: 30,
},

formErroTitulo: {
  fontSize: 20,
  fontWeight: '700',
  color: '#222222',
  marginTop: 12,
  marginBottom: 25,
},

sobreNovaContainer: {
  flexGrow: 1,
  backgroundColor: '#F6F7F9',
  paddingHorizontal: 20,
  paddingTop: 35,
  paddingBottom: 45,
},

sobreHero: {
  alignItems: 'center',
  marginBottom: 32,
},

sobreLogoNova: {
  width: 70,
  height: 70,
  borderRadius: 22,
  backgroundColor: '#EAF1FF',
  alignItems: 'center',
  justifyContent: 'center',
  marginBottom: 22,
},

sobrePequenoTitulo: {
  fontSize: 11,
  fontWeight: '700',
  color: '#2563EB',
  letterSpacing: 1.3,
  marginBottom: 8,
},

sobreTituloNovo: {
  fontSize: 32,
  fontWeight: '700',
  color: '#171717',
  letterSpacing: -0.8,
},

sobreSubtituloNovo: {
  fontSize: 15,
  color: '#737780',
  marginTop: 5,
},

sobreDescricaoNova: {
  maxWidth: 360,
  fontSize: 14,
  lineHeight: 21,
  color: '#737780',
  textAlign: 'center',
  marginTop: 16,
},

sobreCardNovo: {
  width: '100%',
  backgroundColor: '#FFFFFF',
  borderRadius: 18,
  borderWidth: 1,
  borderColor: '#E7E8EB',
  padding: 18,
  marginBottom: 12,
},

sobreCardCabecalho: {
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: 13,
},

sobreIconeNovo: {
  width: 40,
  height: 40,
  borderRadius: 12,
  backgroundColor: '#EEF4FF',
  justifyContent: 'center',
  alignItems: 'center',
  marginRight: 12,
},

sobreCardTituloNovo: {
  fontSize: 16,
  fontWeight: '700',
  color: '#252525',
},

sobreCardTextoNovo: {
  fontSize: 14,
  lineHeight: 21,
  color: '#737780',
},

sobreVersao: {
  width: '100%',
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#ECEEF1',
  borderRadius: 16,
  padding: 15,
  marginTop: 10,
  marginBottom: 18,
},

sobreVersaoTextoContainer: {
  marginLeft: 11,
},

sobreVersaoTitulo: {
  fontSize: 14,
  fontWeight: '700',
  color: '#343434',
},

sobreVersaoTexto: {
  fontSize: 12,
  color: '#858A94',
  marginTop: 2,
},

sobreBotaoVoltarNovo: {
  width: '100%',
  height: 52,
  backgroundColor: '#2563EB',
  borderRadius: 15,
  flexDirection: 'row',
  justifyContent: 'center',
  alignItems: 'center',
},

sobreBotaoVoltarTexto: {
  fontSize: 15,
  fontWeight: '700',
  color: '#FFFFFF',
  marginLeft: 8,
},




});

export default styles;