import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function CadastrarCurso({ navigation }) {

  const [nome, setNome] =
    useState('');

  const [area, setArea] =
    useState('');

  const [descricao, setDescricao] =
    useState('');

  const [duracao, setDuracao] =
    useState('');

  const [cargaHoraria, setCargaHoraria] =
    useState('');

  const [modalidade, setModalidade] =
    useState('');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarCurso = async () => {

    if (
      nome.trim() === '' ||
      area.trim() === '' ||
      descricao.trim() === '' ||
      duracao.trim() === '' ||
      cargaHoraria.trim() === '' ||
      modalidade.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (
      Number(duracao) <= 0 ||
      Number(cargaHoraria) <= 0
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Duração e carga horária devem ser maiores que zero.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/cadastrar_curso.php`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            nome: nome.trim(),
            area: area.trim(),
            descricao:
              descricao.trim(),
            duracao:
              Number(duracao),
            cargaHoraria:
              Number(cargaHoraria),
            modalidade:
              modalidade.trim()
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao cadastrar curso.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Curso cadastrado com sucesso!'
      );


      navigation.navigate(
        'ConsultaCursos'
      );


    } catch (erro) {

      console.log(
        'Erro ao cadastrar curso:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível cadastrar o curso.'
      );


    } finally {

      setSalvando(false);

    }

  };


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          NOVO CADASTRO
        </Text>

        <Text style={styles.formTitulo}>
          Novo curso
        </Text>

        <Text style={styles.formDescricao}>
          Preencha as informações para cadastrar um novo curso.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados do curso
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome do curso
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Digite o nome do curso"
            placeholderTextColor="#A3A7AF"
            value={nome}
            onChangeText={setNome}
            maxLength={40}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Área
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: Tecnologia da Informação"
            placeholderTextColor="#A3A7AF"
            value={area}
            onChangeText={setArea}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Descrição
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            placeholder="Digite uma descrição para o curso"
            placeholderTextColor="#A3A7AF"
            value={descricao}
            onChangeText={setDescricao}
            multiline
            maxLength={255}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Duração em anos
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 2"
            placeholderTextColor="#A3A7AF"
            value={duracao}
            onChangeText={(texto) =>
              setDuracao(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Carga horária
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 1600"
            placeholderTextColor="#A3A7AF"
            value={cargaHoraria}
            onChangeText={(texto) =>
              setCargaHoraria(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Modalidade
          </Text>

          <CampoSelecao
            opcoes={[
              'Presencial',
              'EAD',
              'Hibrido'
            ]}
            value={modalidade}
            onChange={setModalidade}
            placeholder="Selecione a modalidade"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Status
          </Text>

          <TextInput
            style={styles.formInput}
            value="Ativo"
            editable={false}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarCurso}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar curso'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}