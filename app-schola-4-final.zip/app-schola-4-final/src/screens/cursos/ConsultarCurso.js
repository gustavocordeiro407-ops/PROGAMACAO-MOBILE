import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarCurso({ navigation }) {

  const [cursos, setCursos] =
    useState([]);

  const [pesquisa, setPesquisa] =
    useState('');

  const [carregando, setCarregando] =
    useState(true);

  const [erro, setErro] =
    useState('');


  const carregarCursos = async () => {

    try {

      setCarregando(true);
      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_cursos.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar cursos.'
        );

      }


      setCursos(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar cursos:',
        erro
      );


      setErro(
        'Não foi possível carregar os cursos do banco.'
      );


    } finally {

      setCarregando(false);

    }

  };


  useFocusEffect(

    useCallback(() => {

      carregarCursos();

    }, [])

  );


  const cursosFiltrados =
    cursos.filter((curso) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(curso.nome || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(curso.area || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(curso.modalidade || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(curso.descricao || '')
          .toLowerCase()
          .includes(texto)

      );

    });


  const inativarCurso = async (curso) => {

    try {

      const resposta = await fetch(
        `${API_URL}/inativar_curso.php`,
        {
          method: 'PATCH',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: curso.id
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao inativar curso.'
        );

      }


      if (Platform.OS === 'web') {

        window.alert(
          'Curso inativado com sucesso!'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Curso inativado com sucesso!'
        );

      }


      await carregarCursos();


    } catch (erro) {

      console.log(
        'Erro ao inativar curso:',
        erro
      );


      if (Platform.OS === 'web') {

        window.alert(
          'Erro ao inativar o curso.'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Erro ao inativar o curso.'
        );

      }

    }

  };


  const excluirCurso = (curso) => {

    const mensagem =
      `Deseja realmente inativar o curso ${curso.nome}?`;


    if (Platform.OS === 'web') {

      const confirmar =
        window.confirm(mensagem);


      if (confirmar) {

        inativarCurso(curso);

      }

      return;

    }


    Alert.alert(
      'Inativar curso',
      mensagem,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },

        {
          text: 'Inativar',
          style: 'destructive',

          onPress: () =>
            inativarCurso(curso)
        }
      ]
    );

  };


  const renderCurso = ({ item }) => (

    <View style={styles.alunoNovoCard}>


      <View style={styles.alunoAvatar}>

        <Ionicons
          name="school-outline"
          size={22}
          color="#2563EB"
        />

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.nome}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.area ||
            'Área não informada'}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="time-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.duracao} ano(s)
            </Text>

          </View>


          <Text style={styles.alunoMetaPonto}>
            •
          </Text>


          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="hourglass-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.cargaHoraria}h
            </Text>

          </View>

        </View>


        <Text
          style={[
            styles.alunoMetaTexto,
            {
              marginTop: 5
            }
          ]}
          numberOfLines={1}
        >
          {item.modalidade ||
            'Modalidade não informada'}
        </Text>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarCurso',
              {
                curso: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirCurso(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>

    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>


      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          GESTÃO ACADÊMICA
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Cursos
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte, pesquise e gerencie os cursos cadastrados.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar curso..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />

        {pesquisa.length > 0 && (

          <Pressable
            onPress={() =>
              setPesquisa('')
            }
          >

            <Ionicons
              name="close-circle"
              size={20}
              color="#B3B6BC"
            />

          </Pressable>

        )}

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroCurso'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Novo curso
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Cursos cadastrados
        </Text>


        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {cursosFiltrados.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

          <Text
            style={[
              styles.alunoListaVaziaTexto,
              {
                marginTop: 15
              }
            ]}
          >
            Carregando cursos...
          </Text>

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <Ionicons
            name="cloud-offline-outline"
            size={35}
            color="#8A8F98"
          />

          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>

          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>

        </View>

      ) : (

        <FlatList
          data={cursosFiltrados}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderCurso}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <Ionicons
                name="search-outline"
                size={35}
                color="#8A8F98"
              />

              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhum curso encontrado
              </Text>

              <Text style={styles.alunoListaVaziaTexto}>
                Pesquise por nome, área ou modalidade.
              </Text>

            </View>

          }
        />

      )}

    </View>

  );

}