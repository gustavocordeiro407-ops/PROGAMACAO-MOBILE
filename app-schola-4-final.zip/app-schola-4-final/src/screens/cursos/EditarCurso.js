import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarCurso({
  navigation,
  route
}) {

  const curso =
    route.params?.curso;


  const [nome, setNome] =
    useState(curso?.nome || '');

  const [area, setArea] =
    useState(curso?.area || '');

  const [descricao, setDescricao] =
    useState(curso?.descricao || '');

  const [duracao, setDuracao] =
    useState(
      String(curso?.duracao ?? '')
    );

  const [cargaHoraria, setCargaHoraria] =
    useState(
      String(curso?.cargaHoraria ?? '')
    );

  const [modalidade, setModalidade] =
    useState(curso?.modalidade || '');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarAlteracoes = async () => {

    if (
      nome.trim() === '' ||
      area.trim() === '' ||
      descricao.trim() === '' ||
      duracao.trim() === '' ||
      cargaHoraria.trim() === '' ||
      modalidade.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (
      Number(duracao) <= 0 ||
      Number(cargaHoraria) <= 0
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Duração e carga horária devem ser maiores que zero.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_curso.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: curso.id,
            nome: nome.trim(),
            area: area.trim(),
            descricao:
              descricao.trim(),
            duracao:
              Number(duracao),
            cargaHoraria:
              Number(cargaHoraria),
            modalidade:
              modalidade.trim()
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar curso.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Curso atualizado com sucesso!'
      );


      navigation.navigate(
        'ConsultaCursos'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar curso:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar o curso.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!curso) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Curso não encontrado
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar curso
        </Text>

        <Text style={styles.formDescricao}>
          Atualize as informações necessárias e salve.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados do curso
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome do curso
          </Text>

          <TextInput
            style={styles.formInput}
            value={nome}
            onChangeText={setNome}
            maxLength={40}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Área
          </Text>

          <TextInput
            style={styles.formInput}
            value={area}
            onChangeText={setArea}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Descrição
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            value={descricao}
            onChangeText={setDescricao}
            multiline
            maxLength={255}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Duração em anos
          </Text>

          <TextInput
            style={styles.formInput}
            value={duracao}
            onChangeText={(texto) =>
              setDuracao(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Carga horária
          </Text>

          <TextInput
            style={styles.formInput}
            value={cargaHoraria}
            onChangeText={(texto) =>
              setCargaHoraria(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Modalidade
          </Text>

          <CampoSelecao
            opcoes={[
              'Presencial',
              'EAD',
              'Hibrido'
            ]}
            value={modalidade}
            onChange={setModalidade}
            placeholder="Selecione a modalidade"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Status
          </Text>

          <TextInput
            style={styles.formInput}
            value="Ativo"
            editable={false}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}