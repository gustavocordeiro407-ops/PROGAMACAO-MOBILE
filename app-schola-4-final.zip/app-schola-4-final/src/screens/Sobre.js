import React from 'react';

import {
  View,
  Text,
  ScrollView,
  Pressable
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../styles/styles';


export default function Sobre({ navigation }) {

  return (

    <ScrollView
      contentContainerStyle={styles.sobreNovaContainer}
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.sobreHero}>

        <View style={styles.sobreLogoNova}>

          <Ionicons
            name="school"
            size={34}
            color="#2563EB"
          />

        </View>


        <Text style={styles.sobrePequenoTitulo}>
          SOBRE O PROJETO
        </Text>


        <Text style={styles.sobreTituloNovo}>
          APP Scholar
        </Text>


        <Text style={styles.sobreSubtituloNovo}>
          Sistema Acadêmico Mobile
        </Text>


        <Text style={styles.sobreDescricaoNova}>
          Uma aplicação desenvolvida para organizar e facilitar
          o gerenciamento das principais informações acadêmicas.
        </Text>

      </View>


      <View style={styles.sobreCardNovo}>

        <View style={styles.sobreCardCabecalho}>

          <View style={styles.sobreIconeNovo}>
            <Ionicons
              name="grid-outline"
              size={21}
              color="#2563EB"
            />
          </View>

          <Text style={styles.sobreCardTituloNovo}>
            Sistema completo
          </Text>

        </View>


        <Text style={styles.sobreCardTextoNovo}>
          O APP Scholar reúne alunos, professores, turmas,
          cursos, disciplinas, matrículas, responsáveis,
          avaliações, coordenadores e boletins em um único lugar.
        </Text>

      </View>


      <View style={styles.sobreCardNovo}>

        <View style={styles.sobreCardCabecalho}>

          <View style={styles.sobreIconeNovo}>
            <Ionicons
              name="phone-portrait-outline"
              size={21}
              color="#2563EB"
            />
          </View>

          <Text style={styles.sobreCardTituloNovo}>
            Aplicação mobile
          </Text>

        </View>


        <Text style={styles.sobreCardTextoNovo}>
          O projeto foi desenvolvido em React Native utilizando
          Expo, permitindo uma experiência simples e organizada
          em dispositivos móveis.
        </Text>

      </View>


      <View style={styles.sobreCardNovo}>

        <View style={styles.sobreCardCabecalho}>

          <View style={styles.sobreIconeNovo}>
            <Ionicons
              name="code-slash-outline"
              size={21}
              color="#2563EB"
            />
          </View>

          <Text style={styles.sobreCardTituloNovo}>
            Projeto acadêmico
          </Text>

        </View>


        <Text style={styles.sobreCardTextoNovo}>
          Desenvolvido como parte do curso de Desenvolvimento
          de Sistemas, aplicando conceitos de interfaces,
          componentes, navegação e organização de telas.
        </Text>

      </View>


      <View style={styles.sobreVersao}>

        <Ionicons
          name="information-circle-outline"
          size={18}
          color="#8A8F98"
        />

        <View style={styles.sobreVersaoTextoContainer}>

          <Text style={styles.sobreVersaoTitulo}>
            APP Scholar
          </Text>

          <Text style={styles.sobreVersaoTexto}>
            Versão acadêmica
          </Text>

        </View>

      </View>


      <Pressable
        style={styles.sobreBotaoVoltarNovo}
        onPress={() =>
          navigation.goBack()
        }
      >

        <Ionicons
          name="arrow-back"
          size={19}
          color="#FFFFFF"
        />

        <Text style={styles.sobreBotaoVoltarTexto}>
          Voltar ao início
        </Text>

      </Pressable>

    </ScrollView>

  );

}