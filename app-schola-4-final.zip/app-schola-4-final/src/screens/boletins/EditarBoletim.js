import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarBoletim({
  navigation,
  route
}) {

  const boletim =
    route.params?.boletim;


  const [aluno, setAluno] =
    useState(
      String(
        boletim?.aluno ?? ''
      )
    );

  const [turma, setTurma] =
    useState(
      String(
        boletim?.turma ?? ''
      )
    );

  const [periodo, setPeriodo] =
    useState(
      String(
        boletim?.periodo ?? ''
      )
    );

  const [dataEmissao, setDataEmissao] =
    useState(
      String(
        boletim?.dataEmissao ?? ''
      )
    );

  const [mediaFinal, setMediaFinal] =
    useState(
      String(
        boletim?.mediaFinal ?? ''
      )
    );

  const [frequencia, setFrequencia] =
    useState(
      String(
        boletim?.frequencia ?? ''
      )
    );

  const [situacaoFinal, setSituacaoFinal] =
    useState(
      String(
        boletim?.situacaoFinal ?? ''
      )
    );

  const [observacoes, setObservacoes] =
    useState(
      String(
        boletim?.observacoes ?? ''
      )
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvar = async () => {

    if (
      aluno.trim() === '' ||
      turma.trim() === '' ||
      periodo.trim() === '' ||
      dataEmissao.trim() === '' ||
      mediaFinal.trim() === '' ||
      frequencia.trim() === '' ||
      situacaoFinal.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (
      Number(mediaFinal) < 0 ||
      Number(mediaFinal) > 10
    ) {

      mostrarMensagem(
        'APP Scholar',
        'A média final deve estar entre 0 e 10.'
      );

      return;

    }


    if (
      Number(frequencia) < 0 ||
      Number(frequencia) > 100
    ) {

      mostrarMensagem(
        'APP Scholar',
        'A frequência deve estar entre 0 e 100.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_boletim.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            id:
              boletim.id,

            aluno:
              aluno.trim(),

            turma:
              turma.trim(),

            periodo:
              periodo.trim(),

            dataEmissao,

            mediaFinal:
              Number(mediaFinal),

            frequencia:
              Number(frequencia),

            situacaoFinal:
              situacaoFinal.trim(),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar boletim.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Boletim atualizado com sucesso!'
      );


      navigation.navigate(
        'ConsultaBoletins'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar boletim:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar o boletim.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!boletim) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Boletim não encontrado
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar boletim
        </Text>

        <Text style={styles.formDescricao}>
          Atualize os dados gerais do boletim.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados do boletim
      </Text>


      <View style={styles.formCard}>

        {/* ALUNO */}

        <Campo label="Aluno">

          <CampoSelecao
            tipo="alunos"
            value={aluno}
            onChange={setAluno}
            placeholder="Selecione o aluno"
          />

        </Campo>


        <Divisor />


        {/* TURMA */}

        <Campo label="Turma">

          <CampoSelecao
            tipo="turmas"
            value={turma}
            onChange={setTurma}
            placeholder="Selecione a turma"
          />

        </Campo>


        <Divisor />


        <Campo label="Período">

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 1º Bimestre / 2026"
            placeholderTextColor="#A3A7AF"
            value={periodo}
            onChangeText={setPeriodo}
            maxLength={50}
          />

        </Campo>


        <Divisor />


        <Campo label="Data de emissão">

          <TextInput
            style={styles.formInput}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#A3A7AF"
            value={dataEmissao}
            onChangeText={(texto) =>
              setDataEmissao(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </Campo>


        <Divisor />


        <Campo label="Média final">

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 8.5"
            placeholderTextColor="#A3A7AF"
            value={mediaFinal}
            onChangeText={(texto) =>
              setMediaFinal(
                texto
                  .replace(
                    /[^0-9.,]/g,
                    ''
                  )
                  .replace(',', '.')
              )
            }
            keyboardType="decimal-pad"
          />

        </Campo>


        <Divisor />


        <Campo label="Frequência (%)">

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 92"
            placeholderTextColor="#A3A7AF"
            value={frequencia}
            onChangeText={(texto) =>
              setFrequencia(
                texto
                  .replace(
                    /[^0-9.,]/g,
                    ''
                  )
                  .replace(',', '.')
              )
            }
            keyboardType="decimal-pad"
          />

        </Campo>


        <Divisor />


        {/* SITUAÇÃO FINAL */}

        <Campo label="Situação final">

          <CampoSelecao
            opcoes={[
              'Aprovado',
              'Reprovado',
              'Em andamento'
            ]}
            value={situacaoFinal}
            onChange={setSituacaoFinal}
            placeholder="Selecione a situação"
          />

        </Campo>


        <Divisor />


        <Campo label="Observações (opcional)">

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            placeholder="Digite observações, se necessário"
            placeholderTextColor="#A3A7AF"
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </Campo>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvar}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}


function Campo({
  label,
  children
}) {

  return (

    <View style={styles.formCampo}>

      <Text style={styles.formLabel}>
        {label}
      </Text>

      {children}

    </View>

  );

}


function Divisor() {

  return (
    <View style={styles.formDivisor} />
  );

}