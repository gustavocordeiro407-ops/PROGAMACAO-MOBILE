import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, Pressable, FlatList,
  Alert, Platform, ActivityIndicator
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import styles from '../../styles/styles';
import API_URL from '../../services/api';

export default function ConsultarBoletim({ navigation }) {
  const [boletins, setBoletins] = useState([]);
  const [pesquisa, setPesquisa] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const carregarBoletins = async () => {
    try {
      setCarregando(true);
      setErro('');

      const resposta = await fetch(
        `${API_URL}/listar_boletins.php`
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar boletins.'
        );
      }

      setBoletins(resultado.dados || []);
    } catch (erro) {
      console.log('Erro ao carregar boletins:', erro);
      setErro('Não foi possível carregar os boletins.');
    } finally {
      setCarregando(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      carregarBoletins();
    }, [])
  );

  const filtrados = boletins.filter((item) => {
    const texto = pesquisa.trim().toLowerCase();

    return (
      String(item.aluno || '').toLowerCase().includes(texto) ||
      String(item.ra || '').toLowerCase().includes(texto) ||
      String(item.turma || '').toLowerCase().includes(texto) ||
      String(item.periodo || '').toLowerCase().includes(texto) ||
      String(item.situacaoFinal || '').toLowerCase().includes(texto)
    );
  });

  const inativar = async (boletim) => {
    try {
      const resposta = await fetch(
        `${API_URL}/inativar_boletim.php`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            id: boletim.id
          })
        }
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(resultado.mensagem);
      }

      if (Platform.OS === 'web') {
        window.alert('Boletim inativado com sucesso!');
      } else {
        Alert.alert(
          'APP Scholar',
          'Boletim inativado com sucesso!'
        );
      }

      await carregarBoletins();
    } catch (erro) {
      if (Platform.OS === 'web') {
        window.alert(
          erro.message || 'Erro ao inativar o boletim.'
        );
      } else {
        Alert.alert(
          'APP Scholar',
          erro.message || 'Erro ao inativar o boletim.'
        );
      }
    }
  };

  const excluir = (boletim) => {
    const mensagem =
      `Deseja realmente inativar o boletim de ${boletim.aluno}?`;

    if (Platform.OS === 'web') {
      if (window.confirm(mensagem)) {
        inativar(boletim);
      }
      return;
    }

    Alert.alert(
      'Inativar boletim',
      mensagem,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Inativar',
          style: 'destructive',
          onPress: () => inativar(boletim)
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <View style={styles.alunoNovoCard}>
      <View style={styles.alunoAvatar}>
        <Ionicons
          name="stats-chart-outline"
          size={22}
          color="#2563EB"
        />
      </View>

      <View style={styles.alunoCardConteudo}>
        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.aluno}
        </Text>

        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.turma} • {item.periodo}
        </Text>

        <View style={styles.alunoMetaLinha}>
          <Text style={styles.alunoMetaTexto}>
            Média: {item.mediaFinal}
          </Text>

          <Text style={styles.alunoMetaPonto}>•</Text>

          <Text style={styles.alunoMetaTexto}>
            Frequência: {item.frequencia}%
          </Text>
        </View>

        <Text
          style={[
            styles.alunoMetaTexto,
            { marginTop: 5 }
          ]}
        >
          {item.situacaoFinal}
        </Text>
      </View>

      <View style={styles.alunoAcoesNovas}>
        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarBoletim',
              { boletim: item }
            )
          }
        >
          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />
        </Pressable>

        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() => excluir(item)}
        >
          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.alunoNovaContainer}>
      <View style={styles.alunoCabecalhoNovo}>
        <Text style={styles.alunoPequenoTitulo}>
          RESULTADOS ACADÊMICOS
        </Text>
        <Text style={styles.alunoTituloNovo}>
          Boletins
        </Text>
        <Text style={styles.alunoDescricaoNova}>
          Consulte e gerencie os boletins dos alunos.
        </Text>
      </View>

      <View style={styles.alunoPesquisaNova}>
        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar boletim..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />
      </View>

      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate('CadastroBoletim')
        }
      >
        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />
        <Text style={styles.alunoNovoBotaoTexto}>
          Novo boletim
        </Text>
      </Pressable>

      <View style={styles.alunoContagemLinha}>
        <Text style={styles.alunoContagemTitulo}>
          Boletins cadastrados
        </Text>
        <View style={styles.alunoContagemBadge}>
          <Text style={styles.alunoContagemNumero}>
            {filtrados.length}
          </Text>
        </View>
      </View>

      {carregando ? (
        <View style={styles.alunoListaVazia}>
          <ActivityIndicator
            size="large"
            color="#2563EB"
          />
        </View>
      ) : erro ? (
        <View style={styles.alunoListaVazia}>
          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>
          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtrados}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          style={styles.alunoListaNova}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 30 }}
          ListEmptyComponent={
            <View style={styles.alunoListaVazia}>
              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhum boletim encontrado
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}
