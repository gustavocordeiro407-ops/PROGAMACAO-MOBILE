import React from 'react';

import {
  View,
  Text,
  TouchableOpacity
} from 'react-native';

import styles from '../styles/styles';


export default function Acao({
  dados,
  acao,
  voltar
}) {

  let titulo = '';
  let subtitulo = '';


  if (acao === 'cadastro') {
    titulo = `Cadastrar ${dados.singular}`;
    subtitulo = 'Inserção / Cadastro';
  }


  if (acao === 'consulta') {
    titulo = `Consultar ${dados.titulo}`;
    subtitulo = 'Consulta';
  }


  if (acao === 'edicao') {
    titulo = `Editar ${dados.singular}`;
    subtitulo = 'Edição / Alteração';
  }


  return (

    <View style={styles.container}>

      <Text style={styles.titulo}>
        {titulo}
      </Text>

      <Text style={styles.subtitulo}>
        {subtitulo}
      </Text>

      <TouchableOpacity
        style={styles.botaoVoltar}
        onPress={voltar}
      >
        <Text style={styles.textoBotao}>
          Voltar
        </Text>
      </TouchableOpacity>

    </View>

  );

}