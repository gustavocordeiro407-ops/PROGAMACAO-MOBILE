import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarResponsavel({
  navigation,
  route
}) {

  const responsavel =
    route.params?.responsavel;


  const [nome, setNome] =
    useState(
      String(
        responsavel?.nome ?? ''
      )
    );

  const [cpf, setCpf] =
    useState(
      String(
        responsavel?.cpf ?? ''
      )
    );

  const [rg, setRg] =
    useState(
      String(
        responsavel?.rg ?? ''
      )
    );

  const [telefone, setTelefone] =
    useState(
      String(
        responsavel?.telefone ?? ''
      )
    );

  const [email, setEmail] =
    useState(
      String(
        responsavel?.email ?? ''
      )
    );

  const [parentesco, setParentesco] =
    useState(
      String(
        responsavel?.parentesco ?? ''
      )
    );

  const [endereco, setEndereco] =
    useState(
      String(
        responsavel?.endereco ?? ''
      )
    );

  const [observacoes, setObservacoes] =
    useState(
      String(
        responsavel?.observacoes ?? ''
      )
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarAlteracoes = async () => {

    if (
      nome.trim() === '' ||
      cpf.trim() === '' ||
      telefone.trim() === '' ||
      parentesco.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{11}$/.test(cpf)) {

      mostrarMensagem(
        'APP Scholar',
        'O CPF deve possuir exatamente 11 números.'
      );

      return;

    }


    if (!/^\d{11}$/.test(telefone)) {

      mostrarMensagem(
        'APP Scholar',
        'O telefone deve possuir exatamente 11 números.'
      );

      return;

    }


    if (
      email.trim() !== '' &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        email
      )
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um e-mail válido.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_responsavel.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            id:
              responsavel.id,

            nome:
              nome.trim(),

            cpf,

            rg:
              rg.trim(),

            telefone,

            email:
              email.trim(),

            parentesco:
              parentesco.trim(),

            endereco:
              endereco.trim(),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar responsável.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Responsável atualizado com sucesso!'
      );


      navigation.navigate(
        'ConsultaResponsaveis'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar responsável:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar o responsável.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!responsavel) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Responsável não encontrado
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar responsável
        </Text>

        <Text style={styles.formDescricao}>
          Atualize as informações necessárias e salve.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados do responsável
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome completo
          </Text>

          <TextInput
            style={styles.formInput}
            value={nome}
            onChangeText={setNome}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            CPF
          </Text>

          <TextInput
            style={styles.formInput}
            value={cpf}
            onChangeText={(texto) =>
              setCpf(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={11}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            RG (opcional)
          </Text>

          <TextInput
            style={styles.formInput}
            value={rg}
            onChangeText={setRg}
            maxLength={20}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Telefone
          </Text>

          <TextInput
            style={styles.formInput}
            value={telefone}
            onChangeText={(texto) =>
              setTelefone(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="phone-pad"
            maxLength={11}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            E-mail (opcional)
          </Text>

          <TextInput
            style={styles.formInput}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* PARENTESCO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Parentesco
          </Text>

          <CampoSelecao
            opcoes={[
              'Pai',
              'Mae',
              'Tio',
              'Tia',
              'Avo',
              'Responsavel legal'
            ]}
            value={parentesco}
            onChange={setParentesco}
            placeholder="Selecione o parentesco"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Endereço (opcional)
          </Text>

          <TextInput
            style={styles.formInput}
            value={endereco}
            onChangeText={setEndereco}
            maxLength={200}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Observações (opcional)
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}