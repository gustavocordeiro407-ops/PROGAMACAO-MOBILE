import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarResponsavel({
  navigation
}) {

  const [responsaveis, setResponsaveis] =
    useState([]);

  const [pesquisa, setPesquisa] =
    useState('');

  const [carregando, setCarregando] =
    useState(true);

  const [erro, setErro] =
    useState('');


  const carregarResponsaveis = async () => {

    try {

      setCarregando(true);
      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_responsaveis.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar responsáveis.'
        );

      }


      setResponsaveis(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar responsáveis:',
        erro
      );


      setErro(
        'Não foi possível carregar os responsáveis.'
      );


    } finally {

      setCarregando(false);

    }

  };


  useFocusEffect(

    useCallback(() => {

      carregarResponsaveis();

    }, [])

  );


  const responsaveisFiltrados =
    responsaveis.filter((responsavel) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(responsavel.nome || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(responsavel.cpf || '')
          .includes(texto)

        ||

        String(responsavel.rg || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(responsavel.telefone || '')
          .includes(texto)

        ||

        String(responsavel.parentesco || '')
          .toLowerCase()
          .includes(texto)

      );

    });


  const criarIniciais = (nome) => {

    const partes =
      String(nome || '')
        .trim()
        .split(' ')
        .filter(Boolean);


    if (partes.length === 0) {
      return '--';
    }


    if (partes.length === 1) {

      return partes[0]
        .substring(0, 2)
        .toUpperCase();

    }


    return (
      partes[0][0] +
      partes[partes.length - 1][0]
    ).toUpperCase();

  };


  const inativarResponsavel = async (
    responsavel
  ) => {

    try {

      const resposta = await fetch(
        `${API_URL}/inativar_responsavel.php`,
        {
          method: 'PATCH',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: responsavel.id
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem
        );

      }


      if (Platform.OS === 'web') {

        window.alert(
          'Responsável inativado com sucesso!'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Responsável inativado com sucesso!'
        );

      }


      await carregarResponsaveis();


    } catch (erro) {

      console.log(
        'Erro ao inativar responsável:',
        erro
      );


      if (Platform.OS === 'web') {

        window.alert(
          'Erro ao inativar o responsável.'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Erro ao inativar o responsável.'
        );

      }

    }

  };


  const excluirResponsavel = (
    responsavel
  ) => {

    const mensagem =
      `Deseja realmente inativar ${responsavel.nome}?`;


    if (Platform.OS === 'web') {

      if (window.confirm(mensagem)) {

        inativarResponsavel(
          responsavel
        );

      }

      return;

    }


    Alert.alert(
      'Inativar responsável',
      mensagem,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },

        {
          text: 'Inativar',
          style: 'destructive',

          onPress: () =>
            inativarResponsavel(
              responsavel
            )
        }
      ]
    );

  };


  const renderResponsavel = ({ item }) => (

    <View style={styles.alunoNovoCard}>

      <View style={styles.alunoAvatar}>

        <Text style={styles.alunoAvatarTexto}>
          {criarIniciais(item.nome)}
        </Text>

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.nome}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.parentesco}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="card-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.cpf}
            </Text>

          </View>


          <Text style={styles.alunoMetaPonto}>
            •
          </Text>


          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="call-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.telefone}
            </Text>

          </View>

        </View>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarResponsavel',
              {
                responsavel: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirResponsavel(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>

    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>

      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          CONTATOS ACADÊMICOS
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Responsáveis
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte, pesquise e gerencie os responsáveis cadastrados.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar responsável..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroResponsavel'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Novo responsável
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Responsáveis cadastrados
        </Text>

        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {responsaveisFiltrados.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>

          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>

        </View>

      ) : (

        <FlatList
          data={responsaveisFiltrados}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderResponsavel}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhum responsável encontrado
              </Text>

            </View>

          }
        />

      )}

    </View>

  );

}