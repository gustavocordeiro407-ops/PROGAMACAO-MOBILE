import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function CadastrarResponsavel({
  navigation
}) {

  const [nome, setNome] =
    useState('');

  const [cpf, setCpf] =
    useState('');

  const [rg, setRg] =
    useState('');

  const [telefone, setTelefone] =
    useState('');

  const [email, setEmail] =
    useState('');

  const [parentesco, setParentesco] =
    useState('');

  const [endereco, setEndereco] =
    useState('');

  const [observacoes, setObservacoes] =
    useState('');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarResponsavel = async () => {

    if (
      nome.trim() === '' ||
      cpf.trim() === '' ||
      telefone.trim() === '' ||
      parentesco.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{11}$/.test(cpf)) {

      mostrarMensagem(
        'APP Scholar',
        'O CPF deve possuir exatamente 11 números.'
      );

      return;

    }


    if (!/^\d{11}$/.test(telefone)) {

      mostrarMensagem(
        'APP Scholar',
        'O telefone deve possuir exatamente 11 números.'
      );

      return;

    }


    if (
      email.trim() !== '' &&
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        email
      )
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um e-mail válido.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/cadastrar_responsavel.php`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            nome:
              nome.trim(),

            cpf,

            rg:
              rg.trim(),

            telefone,

            email:
              email.trim(),

            parentesco:
              parentesco.trim(),

            endereco:
              endereco.trim(),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao cadastrar responsável.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Responsável cadastrado com sucesso!'
      );


      navigation.navigate(
        'ConsultaResponsaveis'
      );


    } catch (erro) {

      console.log(
        'Erro ao cadastrar responsável:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível cadastrar o responsável.'
      );


    } finally {

      setSalvando(false);

    }

  };


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          NOVO CADASTRO
        </Text>

        <Text style={styles.formTitulo}>
          Novo responsável
        </Text>

        <Text style={styles.formDescricao}>
          Preencha as informações para cadastrar um novo responsável.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados do responsável
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome completo
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Digite o nome completo"
            placeholderTextColor="#A3A7AF"
            value={nome}
            onChangeText={setNome}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            CPF
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Somente números"
            placeholderTextColor="#A3A7AF"
            value={cpf}
            onChangeText={(texto) =>
              setCpf(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={11}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            RG (opcional)
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Digite o RG"
            placeholderTextColor="#A3A7AF"
            value={rg}
            onChangeText={setRg}
            maxLength={20}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Telefone
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Somente números"
            placeholderTextColor="#A3A7AF"
            value={telefone}
            onChangeText={(texto) =>
              setTelefone(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="phone-pad"
            maxLength={11}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            E-mail (opcional)
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="exemplo@email.com"
            placeholderTextColor="#A3A7AF"
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* PARENTESCO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Parentesco
          </Text>

          <CampoSelecao
            opcoes={[
              'Pai',
              'Mae',
              'Tio',
              'Tia',
              'Avo',
              'Responsavel legal'
            ]}
            value={parentesco}
            onChange={setParentesco}
            placeholder="Selecione o parentesco"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Endereço (opcional)
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Digite o endereço"
            placeholderTextColor="#A3A7AF"
            value={endereco}
            onChangeText={setEndereco}
            maxLength={200}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Observações (opcional)
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            placeholder="Digite observações, se necessário"
            placeholderTextColor="#A3A7AF"
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarResponsavel}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar responsável'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}