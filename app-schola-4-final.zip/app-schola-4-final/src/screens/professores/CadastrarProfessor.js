import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function CadastrarProfessor({ navigation }) {

  const [nome, setNome] = useState('');
  const [dataNascimento, setDataNascimento] = useState('');
  const [cpf, setCpf] = useState('');
  const [email, setEmail] = useState('');
  const [telefone, setTelefone] = useState('');
  const [disciplina, setDisciplina] = useState('');
  const [formacao, setFormacao] = useState('');
  const [dataAdmissao, setDataAdmissao] = useState('');

  const [salvando, setSalvando] = useState(false);


  const mostrarMensagem = (titulo, mensagem) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvarProfessor = async () => {

    if (
      nome.trim() === '' ||
      dataNascimento.trim() === '' ||
      cpf.trim() === '' ||
      email.trim() === '' ||
      telefone.trim() === '' ||
      disciplina.trim() === '' ||
      formacao.trim() === '' ||
      dataAdmissao.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{11}$/.test(cpf)) {

      mostrarMensagem(
        'APP Scholar',
        'O CPF deve possuir exatamente 11 números.'
      );

      return;

    }


    if (!/^\d{11}$/.test(telefone)) {

      mostrarMensagem(
        'APP Scholar',
        'O telefone deve possuir exatamente 11 números.'
      );

      return;

    }


    if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        email
      )
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um e-mail válido.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/cadastrar_professor.php`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            nome: nome.trim(),
            dataNascimento,
            cpf,
            email: email.trim(),
            telefone,
            disciplina:
              disciplina.trim(),
            formacao:
              formacao.trim(),
            dataAdmissao
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao cadastrar professor.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Professor cadastrado com sucesso!'
      );


      navigation.navigate(
        'ConsultaProfessores'
      );


    } catch (erro) {

      console.log(
        'Erro ao cadastrar professor:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível cadastrar o professor.'
      );


    } finally {

      setSalvando(false);

    }

  };


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          NOVO CADASTRO
        </Text>

        <Text style={styles.formTitulo}>
          Novo professor
        </Text>

        <Text style={styles.formDescricao}>
          Cadastre as informações pessoais e profissionais do professor.
        </Text>

      </View>


      {/* INFORMAÇÕES PESSOAIS */}

      <Text style={styles.formTituloSecao}>
        Informações pessoais
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome completo
          </Text>


          <TextInput
            style={styles.formInput}
            placeholder="Digite o nome completo"
            placeholderTextColor="#A3A7AF"
            value={nome}
            onChangeText={setNome}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Data de nascimento
          </Text>


          <TextInput
            style={styles.formInput}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#A3A7AF"
            value={dataNascimento}
            onChangeText={(texto) =>
              setDataNascimento(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            CPF
          </Text>


          <TextInput
            style={styles.formInput}
            placeholder="Somente números"
            placeholderTextColor="#A3A7AF"
            value={cpf}
            onChangeText={(texto) =>
              setCpf(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={11}
          />

        </View>

      </View>


      {/* CONTATO */}

      <Text style={styles.formTituloSecao}>
        Contato
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            E-mail
          </Text>


          <TextInput
            style={styles.formInput}
            placeholder="exemplo@escola.com"
            placeholderTextColor="#A3A7AF"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Telefone
          </Text>


          <TextInput
            style={styles.formInput}
            placeholder="Somente números"
            placeholderTextColor="#A3A7AF"
            value={telefone}
            onChangeText={(texto) =>
              setTelefone(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="phone-pad"
            maxLength={11}
          />

        </View>

      </View>


      {/* INFORMAÇÕES PROFISSIONAIS */}

      <Text style={styles.formTituloSecao}>
        Informações profissionais
      </Text>


      <View style={styles.formCard}>

        {/* DISCIPLINA */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Disciplina / Área de atuação
          </Text>


          <CampoSelecao
            tipo="disciplinas"
            value={disciplina}
            onChange={setDisciplina}
            placeholder="Selecione a disciplina"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* FORMAÇÃO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Formação
          </Text>


          <CampoSelecao
            tipo="formacoes"
            value={formacao}
            onChange={setFormacao}
            placeholder="Selecione a formação"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* DATA DE ADMISSÃO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Data de admissão
          </Text>


          <TextInput
            style={styles.formInput}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#A3A7AF"
            value={dataAdmissao}
            onChangeText={(texto) =>
              setDataAdmissao(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>

      </View>


      {/* BOTÕES */}

      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarProfessor}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />


          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}