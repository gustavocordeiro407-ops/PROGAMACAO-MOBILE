import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarProfessor({
  navigation,
  route
}) {

  const professor =
    route.params?.professor;


  const [nome, setNome] =
    useState(professor?.nome || '');

  const [dataNascimento, setDataNascimento] =
    useState(professor?.dataNascimento || '');

  const [cpf, setCpf] =
    useState(professor?.cpf || '');

  const [email, setEmail] =
    useState(professor?.email || '');

  const [telefone, setTelefone] =
    useState(professor?.telefone || '');

  const [disciplina, setDisciplina] =
    useState(professor?.disciplina || '');

  const [formacao, setFormacao] =
    useState(professor?.formacao || '');

  const [dataAdmissao, setDataAdmissao] =
    useState(professor?.dataAdmissao || '');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvarAlteracoes = async () => {

    if (
      nome.trim() === '' ||
      dataNascimento.trim() === '' ||
      cpf.trim() === '' ||
      email.trim() === '' ||
      telefone.trim() === '' ||
      disciplina.trim() === '' ||
      formacao.trim() === '' ||
      dataAdmissao.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{11}$/.test(cpf)) {

      mostrarMensagem(
        'APP Scholar',
        'O CPF deve possuir exatamente 11 números.'
      );

      return;

    }


    if (!/^\d{11}$/.test(telefone)) {

      mostrarMensagem(
        'APP Scholar',
        'O telefone deve possuir exatamente 11 números.'
      );

      return;

    }


    if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        email
      )
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um e-mail válido.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_professor.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: professor.id,
            nome: nome.trim(),
            dataNascimento,
            cpf,
            email: email.trim(),
            telefone,
            disciplina:
              disciplina.trim(),
            formacao:
              formacao.trim(),
            dataAdmissao
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar professor.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Professor atualizado com sucesso!'
      );


      navigation.navigate(
        'ConsultaProfessores'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar professor:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar o professor.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!professor) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Professor não encontrado
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar professor
        </Text>

        <Text style={styles.formDescricao}>
          Atualize os dados pessoais e profissionais do professor.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Informações pessoais
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome completo
          </Text>

          <TextInput
            style={styles.formInput}
            value={nome}
            onChangeText={setNome}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Data de nascimento
          </Text>

          <TextInput
            style={styles.formInput}
            value={dataNascimento}
            onChangeText={(texto) =>
              setDataNascimento(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            CPF
          </Text>

          <TextInput
            style={styles.formInput}
            value={cpf}
            onChangeText={(texto) =>
              setCpf(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={11}
          />

        </View>

      </View>


      <Text style={styles.formTituloSecao}>
        Contato
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            E-mail
          </Text>

          <TextInput
            style={styles.formInput}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Telefone
          </Text>

          <TextInput
            style={styles.formInput}
            value={telefone}
            onChangeText={(texto) =>
              setTelefone(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="phone-pad"
            maxLength={11}
          />

        </View>

      </View>


      <Text style={styles.formTituloSecao}>
        Informações profissionais
      </Text>


      <View style={styles.formCard}>

        {/* DISCIPLINA */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Disciplina / Área de atuação
          </Text>

          <CampoSelecao
            tipo="disciplinas"
            value={disciplina}
            onChange={setDisciplina}
            placeholder="Selecione a disciplina"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* FORMAÇÃO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Formação
          </Text>

          <CampoSelecao
            tipo="formacoes"
            value={formacao}
            onChange={setFormacao}
            placeholder="Selecione a formação"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Data de admissão
          </Text>

          <TextInput
            style={styles.formInput}
            value={dataAdmissao}
            onChangeText={(texto) =>
              setDataAdmissao(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />


          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}