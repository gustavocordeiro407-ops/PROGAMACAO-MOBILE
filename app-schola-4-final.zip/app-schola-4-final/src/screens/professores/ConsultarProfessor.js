import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarProfessor({ navigation }) {

  const [professores, setProfessores] =
    useState([]);

  const [pesquisa, setPesquisa] =
    useState('');

  const [carregando, setCarregando] =
    useState(true);

  const [erro, setErro] =
    useState('');


  const carregarProfessores = async () => {

    try {

      setCarregando(true);

      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_professores.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao consultar professores.'
        );

      }


      setProfessores(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar professores:',
        erro
      );


      setErro(
        'Não foi possível carregar os professores do banco.'
      );


    } finally {

      setCarregando(false);

    }

  };


  useFocusEffect(

    useCallback(() => {

      carregarProfessores();

    }, [])

  );


  const professoresFiltrados =
    professores.filter((professor) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(professor.nome || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(professor.cpf || '')
          .includes(texto)

        ||

        String(professor.email || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(professor.formacao || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(professor.disciplina || '')
          .toLowerCase()
          .includes(texto)

      );

    });


  const criarIniciais = (nome) => {

    if (!nome) {
      return '--';
    }


    const partes =
      nome
        .trim()
        .split(' ')
        .filter(Boolean);


    if (partes.length === 1) {

      return partes[0]
        .substring(0, 2)
        .toUpperCase();

    }


    return (
      partes[0][0] +
      partes[partes.length - 1][0]
    ).toUpperCase();

  };


  const inativarProfessor = async (professor) => {

    try {

      const resposta = await fetch(
        `${API_URL}/inativar_professor.php`,
        {
          method: 'PATCH',

          headers: {
            'Content-Type': 'application/json'
          },

          body: JSON.stringify({
            id: professor.id
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao inativar professor.'
        );

      }


      if (Platform.OS === 'web') {

        window.alert(
          'Professor inativado com sucesso!'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Professor inativado com sucesso!'
        );

      }


      await carregarProfessores();


    } catch (erro) {

      console.log(
        'Erro ao inativar professor:',
        erro
      );


      if (Platform.OS === 'web') {

        window.alert(
          'Erro ao inativar professor.'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Erro ao inativar professor.'
        );

      }

    }

  };


  const excluirProfessor = (professor) => {

    const mensagem =
      `Deseja realmente inativar o professor ${professor.nome}?`;


    if (Platform.OS === 'web') {

      const confirmar =
        window.confirm(mensagem);


      if (confirmar) {

        inativarProfessor(professor);

      }


      return;

    }


    Alert.alert(
      'Inativar professor',
      mensagem,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },

        {
          text: 'Inativar',
          style: 'destructive',

          onPress: () =>
            inativarProfessor(professor)
        }
      ]
    );

  };


  const renderProfessor = ({ item }) => (

    <View style={styles.alunoNovoCard}>


      <View style={styles.alunoAvatar}>

        <Text style={styles.alunoAvatarTexto}>
          {criarIniciais(item.nome)}
        </Text>

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.nome}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.disciplina ||
            'Disciplina não informada'}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="school-outline"
              size={14}
              color="#8A8F98"
            />

            <Text
              style={styles.alunoMetaTexto}
              numberOfLines={1}
            >
              {item.formacao ||
                'Formação não informada'}
            </Text>

          </View>

        </View>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarProfessor',
              {
                professor: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirProfessor(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>

    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>


      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          CORPO DOCENTE
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Professores
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte, pesquise e gerencie os professores cadastrados.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />


        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar professor..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />


        {pesquisa.length > 0 && (

          <Pressable
            onPress={() =>
              setPesquisa('')
            }
          >

            <Ionicons
              name="close-circle"
              size={20}
              color="#B3B6BC"
            />

          </Pressable>

        )}

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroProfessor'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Novo professor
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Professores cadastrados
        </Text>


        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {professoresFiltrados.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

          <Text
            style={[
              styles.alunoListaVaziaTexto,
              {
                marginTop: 15
              }
            ]}
          >
            Carregando professores...
          </Text>

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <View style={styles.alunoListaVaziaIcone}>

            <Ionicons
              name="cloud-offline-outline"
              size={28}
              color="#8A8F98"
            />

          </View>


          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>


          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>


          <Pressable
            style={[
              styles.alunoNovoBotao,
              {
                marginTop: 20
              }
            ]}
            onPress={carregarProfessores}
          >

            <Text style={styles.alunoNovoBotaoTexto}>
              Tentar novamente
            </Text>

          </Pressable>

        </View>

      ) : (

        <FlatList
          data={professoresFiltrados}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderProfessor}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <View style={styles.alunoListaVaziaIcone}>

                <Ionicons
                  name="search-outline"
                  size={28}
                  color="#8A8F98"
                />

              </View>


              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhum professor encontrado
              </Text>


              <Text style={styles.alunoListaVaziaTexto}>
                Pesquise por nome, CPF, formação ou disciplina.
              </Text>

            </View>

          }
        />

      )}

    </View>

  );

}