import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarTurma({
  navigation,
  route
}) {

  const turma =
    route.params?.turma;


  const [sala, setSala] =
    useState(
      String(turma?.sala ?? '')
    );

  const [turno, setTurno] =
    useState(
      String(turma?.turno ?? '')
    );

  const [anoLetivo, setAnoLetivo] =
    useState(
      String(turma?.anoLetivo ?? '')
    );

  const [curso, setCurso] =
    useState(
      String(turma?.curso ?? '')
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarAlteracoes = async () => {

    if (
      sala.trim() === '' ||
      turno.trim() === '' ||
      anoLetivo.trim() === '' ||
      curso.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{4}$/.test(anoLetivo)) {

      mostrarMensagem(
        'APP Scholar',
        'O ano letivo deve possuir 4 números.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_turma.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: turma.id,
            sala: sala.trim(),
            turno: turno.trim(),
            anoLetivo:
              anoLetivo.trim(),
            curso: curso.trim()
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar turma.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Turma atualizada com sucesso!'
      );


      navigation.navigate(
        'ConsultaTurmas'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar turma:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar a turma.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!turma) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Turma não encontrada
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar turma
        </Text>

        <Text style={styles.formDescricao}>
          Atualize as informações da turma.
        </Text>

      </View>


      {/* IDENTIFICAÇÃO */}

      <Text style={styles.formTituloSecao}>
        Identificação
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Sala / Turma
          </Text>

          <TextInput
            style={styles.formInput}
            value={sala}
            onChangeText={setSala}
            maxLength={20}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Curso
          </Text>

          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>

      </View>


      {/* PERÍODO */}

      <Text style={styles.formTituloSecao}>
        Período
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Turno
          </Text>

          <CampoSelecao
            opcoes={[
              'Manha',
              'Tarde',
              'Noite'
            ]}
            value={turno}
            onChange={setTurno}
            placeholder="Selecione o turno"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Ano letivo
          </Text>

          <TextInput
            style={styles.formInput}
            value={anoLetivo}
            onChangeText={(texto) =>
              setAnoLetivo(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={4}
          />

        </View>

      </View>


      {/* BOTÕES */}

      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}