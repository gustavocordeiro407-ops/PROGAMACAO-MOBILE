import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function CadastrarTurma({ navigation }) {

  const [sala, setSala] =
    useState('');

  const [turno, setTurno] =
    useState('');

  const [anoLetivo, setAnoLetivo] =
    useState('');

  const [curso, setCurso] =
    useState('');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarTurma = async () => {

    if (
      sala.trim() === '' ||
      turno.trim() === '' ||
      anoLetivo.trim() === '' ||
      curso.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{4}$/.test(anoLetivo)) {

      mostrarMensagem(
        'APP Scholar',
        'O ano letivo deve possuir 4 números.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/cadastrar_turma.php`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            sala: sala.trim(),
            turno: turno.trim(),
            anoLetivo:
              anoLetivo.trim(),
            curso: curso.trim()
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao cadastrar turma.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Turma cadastrada com sucesso!'
      );


      navigation.navigate(
        'ConsultaTurmas'
      );


    } catch (erro) {

      console.log(
        'Erro no cadastro:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível cadastrar a turma.'
      );


    } finally {

      setSalvando(false);

    }

  };


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          NOVO CADASTRO
        </Text>

        <Text style={styles.formTitulo}>
          Nova turma
        </Text>

        <Text style={styles.formDescricao}>
          Cadastre uma nova turma no sistema.
        </Text>

      </View>


      {/* IDENTIFICAÇÃO */}

      <Text style={styles.formTituloSecao}>
        Identificação
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Sala / Turma
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: DS-2"
            placeholderTextColor="#A3A7AF"
            value={sala}
            onChangeText={setSala}
            maxLength={20}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Curso
          </Text>

          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>

      </View>


      {/* PERÍODO */}

      <Text style={styles.formTituloSecao}>
        Período
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Turno
          </Text>

          <CampoSelecao
            opcoes={[
              'Manha',
              'Tarde',
              'Noite'
            ]}
            value={turno}
            onChange={setTurno}
            placeholder="Selecione o turno"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Ano letivo
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 2026"
            placeholderTextColor="#A3A7AF"
            value={anoLetivo}
            onChangeText={(texto) =>
              setAnoLetivo(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={4}
          />

        </View>

      </View>


      {/* BOTÕES */}

      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarTurma}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar turma'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}