import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarTurma({ navigation }) {

  const [turmas, setTurmas] =
    useState([]);

  const [pesquisa, setPesquisa] =
    useState('');

  const [carregando, setCarregando] =
    useState(true);

  const [erro, setErro] =
    useState('');


  const carregarTurmas = async () => {

    try {

      setCarregando(true);

      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_turmas.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar turmas.'
        );

      }


      setTurmas(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar turmas:',
        erro
      );


      setErro(
        'Não foi possível carregar as turmas do banco.'
      );


    } finally {

      setCarregando(false);

    }

  };


  useFocusEffect(

    useCallback(() => {

      carregarTurmas();

    }, [])

  );


  const turmasFiltradas =
    turmas.filter((turma) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(turma.sala || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(turma.turno || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(turma.anoLetivo || '')
          .includes(texto)

        ||

        String(turma.curso || '')
          .toLowerCase()
          .includes(texto)

      );

    });


  const inativarTurma = async (turma) => {

    try {

      const resposta = await fetch(
        `${API_URL}/inativar_turma.php`,
        {
          method: 'PATCH',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: turma.id
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao inativar turma.'
        );

      }


      if (Platform.OS === 'web') {

        window.alert(
          'Turma inativada com sucesso!'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Turma inativada com sucesso!'
        );

      }


      await carregarTurmas();


    } catch (erro) {

      console.log(
        'Erro ao inativar turma:',
        erro
      );


      if (Platform.OS === 'web') {

        window.alert(
          'Erro ao inativar a turma.'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Erro ao inativar a turma.'
        );

      }

    }

  };


  const excluirTurma = (turma) => {

    const mensagem =
      `Deseja realmente inativar a turma ${turma.sala}?`;


    if (Platform.OS === 'web') {

      const confirmar =
        window.confirm(mensagem);


      if (confirmar) {

        inativarTurma(turma);

      }


      return;

    }


    Alert.alert(
      'Inativar turma',
      mensagem,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },

        {
          text: 'Inativar',
          style: 'destructive',

          onPress: () =>
            inativarTurma(turma)
        }
      ]
    );

  };


  const renderTurma = ({ item }) => (

    <View style={styles.alunoNovoCard}>


      <View style={styles.alunoAvatar}>

        <Ionicons
          name="people-outline"
          size={22}
          color="#2563EB"
        />

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.sala}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.curso ||
            'Curso não informado'}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="time-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.turno}
            </Text>

          </View>


          <Text style={styles.alunoMetaPonto}>
            •
          </Text>


          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="calendar-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.anoLetivo}
            </Text>

          </View>

        </View>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarTurma',
              {
                turma: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirTurma(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>

    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>


      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          ORGANIZAÇÃO ACADÊMICA
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Turmas
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte e gerencie as turmas cadastradas.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar turma..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />

        {pesquisa.length > 0 && (

          <Pressable
            onPress={() =>
              setPesquisa('')
            }
          >

            <Ionicons
              name="close-circle"
              size={20}
              color="#B3B6BC"
            />

          </Pressable>

        )}

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroTurma'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Nova turma
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Turmas cadastradas
        </Text>


        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {turmasFiltradas.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

          <Text
            style={[
              styles.alunoListaVaziaTexto,
              {
                marginTop: 15
              }
            ]}
          >
            Carregando turmas...
          </Text>

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <Ionicons
            name="cloud-offline-outline"
            size={35}
            color="#8A8F98"
          />

          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>

          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>

        </View>

      ) : (

        <FlatList
          data={turmasFiltradas}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderTurma}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <Ionicons
                name="search-outline"
                size={35}
                color="#8A8F98"
              />

              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhuma turma encontrada
              </Text>

              <Text style={styles.alunoListaVaziaTexto}>
                Pesquise por sala, curso, turno ou ano.
              </Text>

            </View>

          }
        />

      )}

    </View>

  );

}