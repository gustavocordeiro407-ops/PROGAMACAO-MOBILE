import React from 'react';

import {
  View,
  Text,
  TouchableOpacity
} from 'react-native';

import styles from '../styles/styles';


export default function MenuModulo({
  dados,
  abrirAcao,
  voltar
}) {

  return (

    <View style={styles.container}>

      <Text style={styles.titulo}>
        {dados.titulo}
      </Text>

      <Text style={styles.subtitulo}>
        Escolha uma opção
      </Text>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => abrirAcao('cadastro')}
      >
        <Text style={styles.textoBotao}>
          Cadastrar {dados.singular}
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => abrirAcao('consulta')}
      >
        <Text style={styles.textoBotao}>
          Consultar {dados.titulo}
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botao}
        onPress={() => abrirAcao('edicao')}
      >
        <Text style={styles.textoBotao}>
          Editar {dados.singular}
        </Text>
      </TouchableOpacity>


      <TouchableOpacity
        style={styles.botaoVoltar}
        onPress={voltar}
      >
        <Text style={styles.textoBotao}>
          Voltar
        </Text>
      </TouchableOpacity>

    </View>

  );

}