import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarAluno({ navigation }) {

  const [alunos, setAlunos] = useState([]);

  const [pesquisa, setPesquisa] = useState('');

  const [carregando, setCarregando] = useState(true);

  const [erro, setErro] = useState('');


  const carregarAlunos = async () => {

    try {

      setCarregando(true);

      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_alunos.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao consultar alunos.'
        );

      }


      setAlunos(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar alunos:',
        erro
      );


      setErro(
        'Não foi possível carregar os alunos do banco.'
      );


    } finally {

      setCarregando(false);

    }

  };


  // SEMPRE QUE A TELA FOR ABERTA,
  // CONSULTA O BANCO NOVAMENTE
  useFocusEffect(

    useCallback(() => {

      carregarAlunos();

    }, [])

  );


  const alunosFiltrados =
    alunos.filter((aluno) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(aluno.nome || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(aluno.ra || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(aluno.cpf || '')
          .includes(texto)

        ||

        String(aluno.curso || '')
          .toLowerCase()
          .includes(texto)

      );

    });


  const criarIniciais = (nome) => {

    if (!nome) {
      return '--';
    }


    const partes =
      nome
        .trim()
        .split(' ')
        .filter(Boolean);


    if (partes.length === 1) {

      return partes[0]
        .substring(0, 2)
        .toUpperCase();

    }


    return (
      partes[0][0] +
      partes[partes.length - 1][0]
    ).toUpperCase();

  };


  // POR ENQUANTO A EXCLUSÃO
  // SERÁ CONECTADA NA PRÓXIMA ETAPA
 const inativarAluno = async (aluno) => {

  try {

    const resposta = await fetch(
      `${API_URL}/inativar_aluno.php`,
      {
        method: 'PATCH',

        headers: {
          'Content-Type': 'application/json'
        },

        body: JSON.stringify({
          id: aluno.id
        })
      }
    );


    const resultado =
      await resposta.json();


    if (!resultado.sucesso) {

      throw new Error(
        resultado.mensagem ||
        'Não foi possível inativar o aluno.'
      );

    }


    if (Platform.OS === 'web') {

      window.alert(
        'Aluno inativado com sucesso!'
      );

    } else {

      Alert.alert(
        'APP Scholar',
        'Aluno inativado com sucesso!'
      );

    }


    // BUSCA NOVAMENTE OS ALUNOS ATIVOS
    await carregarAlunos();


  } catch (erro) {

    console.log(
      'Erro ao inativar aluno:',
      erro
    );


    if (Platform.OS === 'web') {

      window.alert(
        'Erro ao inativar o aluno.'
      );

    } else {

      Alert.alert(
        'APP Scholar',
        'Erro ao inativar o aluno.'
      );

    }

  }

};



const excluirAluno = (aluno) => {

  const mensagem =
    `Deseja realmente inativar o aluno ${aluno.nome}?`;


  if (Platform.OS === 'web') {

    const confirmar =
      window.confirm(mensagem);


    if (confirmar) {

      inativarAluno(aluno);

    }


    return;

  }


  Alert.alert(
    'Inativar aluno',
    mensagem,
    [
      {
        text: 'Cancelar',
        style: 'cancel'
      },

      {
        text: 'Inativar',
        style: 'destructive',

        onPress: () =>
          inativarAluno(aluno)
      }
    ]
  );

};


  const renderAluno = ({ item }) => (

    <View style={styles.alunoNovoCard}>


      <View style={styles.alunoAvatar}>

        <Text style={styles.alunoAvatarTexto}>
          {criarIniciais(item.nome)}
        </Text>

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.nome}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.curso || 'Curso não informado'}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="id-card-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.ra}
            </Text>

          </View>


          <View style={styles.alunoMetaPonto} />


          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="school-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.turma || '--'}
            </Text>

          </View>

        </View>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarAluno',
              {
                aluno: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirAluno(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>


    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>


      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          GERENCIAMENTO
        </Text>


        <Text style={styles.alunoTituloNovo}>
          Alunos
        </Text>


        <Text style={styles.alunoDescricaoNova}>
          Consulte, pesquise e gerencie os alunos cadastrados.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />


        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar aluno..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />


        {pesquisa.length > 0 && (

          <Pressable
            onPress={() =>
              setPesquisa('')
            }
          >

            <Ionicons
              name="close-circle"
              size={20}
              color="#B3B6BC"
            />

          </Pressable>

        )}

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroAluno'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Novo aluno
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Alunos cadastrados
        </Text>


        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {alunosFiltrados.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

          <Text
            style={[
              styles.alunoListaVaziaTexto,
              {
                marginTop: 15
              }
            ]}
          >
            Carregando alunos...
          </Text>

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <View style={styles.alunoListaVaziaIcone}>

            <Ionicons
              name="cloud-offline-outline"
              size={28}
              color="#8A8F98"
            />

          </View>


          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>


          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>


          <Pressable
            style={[
              styles.alunoNovoBotao,
              {
                marginTop: 20
              }
            ]}
            onPress={carregarAlunos}
          >

            <Text style={styles.alunoNovoBotaoTexto}>
              Tentar novamente
            </Text>

          </Pressable>

        </View>

      ) : (

        <FlatList
          data={alunosFiltrados}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderAluno}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <View style={styles.alunoListaVaziaIcone}>

                <Ionicons
                  name="search-outline"
                  size={28}
                  color="#8A8F98"
                />

              </View>


              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhum aluno encontrado
              </Text>


              <Text style={styles.alunoListaVaziaTexto}>
                Tente pesquisar utilizando outro nome, RA, CPF ou curso.
              </Text>

            </View>

          }
        />

      )}


    </View>

  );

}