import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarAluno({
  navigation,
  route
}) {

  const aluno =
    route.params?.aluno;


  const [nome, setNome] =
    useState(aluno?.nome || '');

  const [dataNascimento, setDataNascimento] =
    useState(aluno?.dataNascimento || '');

  const [cpf, setCpf] =
    useState(aluno?.cpf || '');

  const [ra, setRa] =
    useState(aluno?.ra || '');

  const [email, setEmail] =
    useState(aluno?.email || '');

  const [telefone, setTelefone] =
    useState(aluno?.telefone || '');

  const [curso, setCurso] =
    useState(aluno?.curso || '');

  const [turma, setTurma] =
    useState(aluno?.turma || '');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvarAlteracoes = async () => {

    if (
      nome.trim() === '' ||
      dataNascimento.trim() === '' ||
      cpf.trim() === '' ||
      ra.trim() === '' ||
      email.trim() === '' ||
      telefone.trim() === '' ||
      curso.trim() === '' ||
      turma.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    const nomeValido =
      /^[A-Za-zÀ-ÖØ-öø-ÿ\s'-]+$/;


    if (!nomeValido.test(nome)) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um nome válido.'
      );

      return;

    }


    const formatoData =
      /^\d{2}\/\d{2}\/\d{4}$/;


    if (!formatoData.test(dataNascimento)) {

      mostrarMensagem(
        'APP Scholar',
        'Digite a data no formato DD/MM/AAAA.'
      );

      return;

    }


    if (!/^\d{11}$/.test(cpf)) {

      mostrarMensagem(
        'APP Scholar',
        'O CPF deve possuir exatamente 11 números.'
      );

      return;

    }


    if (ra.trim().length > 13) {

      mostrarMensagem(
        'APP Scholar',
        'O RA pode possuir no máximo 13 caracteres.'
      );

      return;

    }


    if (!/^\d{11}$/.test(telefone)) {

      mostrarMensagem(
        'APP Scholar',
        'O telefone deve possuir exatamente 11 números.'
      );

      return;

    }


    const emailValido =
      /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


    if (!emailValido.test(email)) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um e-mail válido.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_aluno.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            id: aluno.id,

            nome: nome.trim(),

            dataNascimento,

            cpf,

            ra: ra.trim(),

            email: email.trim(),

            telefone,

            curso: curso.trim(),

            turma: turma.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar aluno.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Aluno atualizado com sucesso!'
      );


      navigation.navigate(
        'ConsultaAlunos'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar aluno:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar o aluno.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!aluno) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Aluno não encontrado
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar aluno
        </Text>

        <Text style={styles.formDescricao}>
          Atualize os dados do aluno e salve as alterações.
        </Text>

      </View>


      {/* INFORMAÇÕES PESSOAIS */}

      <Text style={styles.formTituloSecao}>
        Informações pessoais
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="person-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              Nome completo
            </Text>

          </View>


          <TextInput
            style={styles.formInput}
            value={nome}
            onChangeText={setNome}
            maxLength={120}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="calendar-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              Data de nascimento
            </Text>

          </View>


          <TextInput
            style={styles.formInput}
            value={dataNascimento}
            onChangeText={(texto) =>
              setDataNascimento(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>

      </View>


      {/* DOCUMENTOS */}

      <Text style={styles.formTituloSecao}>
        Documentos
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="card-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              CPF
            </Text>

          </View>


          <TextInput
            style={styles.formInput}
            value={cpf}
            onChangeText={(texto) =>
              setCpf(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={11}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="id-card-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              RA
            </Text>

          </View>


          <TextInput
            style={styles.formInput}
            value={ra}
            onChangeText={setRa}
            maxLength={13}
          />

        </View>

      </View>


      {/* CONTATO */}

      <Text style={styles.formTituloSecao}>
        Contato
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="mail-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              E-mail
            </Text>

          </View>


          <TextInput
            style={styles.formInput}
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="call-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              Telefone
            </Text>

          </View>


          <TextInput
            style={styles.formInput}
            value={telefone}
            onChangeText={(texto) =>
              setTelefone(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="phone-pad"
            maxLength={11}
          />

        </View>

      </View>


      {/* ACADÊMICO */}

      <Text style={styles.formTituloSecao}>
        Acadêmico
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="layers-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              Curso
            </Text>

          </View>


          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <View style={styles.formLabelLinha}>

            <Ionicons
              name="school-outline"
              size={17}
              color="#737780"
            />

            <Text style={styles.formLabel}>
              Turma
            </Text>

          </View>


          <CampoSelecao
            tipo="turmas"
            value={turma}
            onChange={setTurma}
            placeholder="Selecione a turma"
            onSelectItem={(item) => {

              setTurma(item.valor);

              if (item.curso) {

                setCurso(item.curso);

              }

            }}
          />

        </View>

      </View>


      {/* BOTÕES */}

      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}