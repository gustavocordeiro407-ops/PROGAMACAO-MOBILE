import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, Pressable, FlatList,
  Alert, Platform, ActivityIndicator
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import styles from '../../styles/styles';
import API_URL from '../../services/api';

export default function ConsultarCoordenador({ navigation }) {
  const [coordenadores, setCoordenadores] = useState([]);
  const [pesquisa, setPesquisa] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const carregarCoordenadores = async () => {
    try {
      setCarregando(true);
      setErro('');

      const resposta = await fetch(
        `${API_URL}/listar_coordenadores.php`
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar coordenadores.'
        );
      }

      setCoordenadores(resultado.dados || []);
    } catch (erro) {
      console.log('Erro ao carregar coordenadores:', erro);
      setErro('Não foi possível carregar os coordenadores.');
    } finally {
      setCarregando(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      carregarCoordenadores();
    }, [])
  );

  const filtrados = coordenadores.filter((item) => {
    const texto = pesquisa.trim().toLowerCase();

    return (
      String(item.nome || '').toLowerCase().includes(texto) ||
      String(item.email || '').toLowerCase().includes(texto) ||
      String(item.departamento || '').toLowerCase().includes(texto) ||
      String(item.formacao || '').toLowerCase().includes(texto)
    );
  });

  const iniciais = (nome) => {
    const partes = String(nome || '')
      .trim()
      .split(' ')
      .filter(Boolean);

    if (partes.length === 0) return '--';

    if (partes.length === 1) {
      return partes[0]
        .substring(0, 2)
        .toUpperCase();
    }

    return (
      partes[0][0] +
      partes[partes.length - 1][0]
    ).toUpperCase();
  };

  const inativar = async (coordenador) => {
    try {
      const resposta = await fetch(
        `${API_URL}/inativar_coordenador.php`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            id: coordenador.id
          })
        }
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(resultado.mensagem);
      }

      if (Platform.OS === 'web') {
        window.alert('Coordenador inativado com sucesso!');
      } else {
        Alert.alert(
          'APP Scholar',
          'Coordenador inativado com sucesso!'
        );
      }

      await carregarCoordenadores();
    } catch (erro) {
      if (Platform.OS === 'web') {
        window.alert(
          erro.message || 'Erro ao inativar coordenador.'
        );
      } else {
        Alert.alert(
          'APP Scholar',
          erro.message || 'Erro ao inativar coordenador.'
        );
      }
    }
  };

  const excluir = (coordenador) => {
    const mensagem =
      `Deseja realmente inativar ${coordenador.nome}?`;

    if (Platform.OS === 'web') {
      if (window.confirm(mensagem)) {
        inativar(coordenador);
      }
      return;
    }

    Alert.alert(
      'Inativar coordenador',
      mensagem,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Inativar',
          style: 'destructive',
          onPress: () => inativar(coordenador)
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <View style={styles.alunoNovoCard}>
      <View style={styles.alunoAvatar}>
        <Text style={styles.alunoAvatarTexto}>
          {iniciais(item.nome)}
        </Text>
      </View>

      <View style={styles.alunoCardConteudo}>
        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.nome}
        </Text>

        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.departamento ||
            'Departamento não informado'}
        </Text>

        <View style={styles.alunoMetaLinha}>
          <Ionicons
            name="mail-outline"
            size={14}
            color="#8A8F98"
          />

          <Text
            style={styles.alunoMetaTexto}
            numberOfLines={1}
          >
            {item.email}
          </Text>
        </View>

        <Text
          style={[
            styles.alunoMetaTexto,
            { marginTop: 5 }
          ]}
          numberOfLines={1}
        >
          {item.formacao ||
            'Formação não informada'}
        </Text>
      </View>

      <View style={styles.alunoAcoesNovas}>
        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarCoordenador',
              { coordenador: item }
            )
          }
        >
          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />
        </Pressable>

        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() => excluir(item)}
        >
          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.alunoNovaContainer}>
      <View style={styles.alunoCabecalhoNovo}>
        <Text style={styles.alunoPequenoTitulo}>
          GESTÃO ESCOLAR
        </Text>
        <Text style={styles.alunoTituloNovo}>
          Coordenadores
        </Text>
        <Text style={styles.alunoDescricaoNova}>
          Consulte e gerencie os coordenadores cadastrados.
        </Text>
      </View>

      <View style={styles.alunoPesquisaNova}>
        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar coordenador..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />
      </View>

      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate('CadastroCoordenador')
        }
      >
        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />
        <Text style={styles.alunoNovoBotaoTexto}>
          Novo coordenador
        </Text>
      </Pressable>

      <View style={styles.alunoContagemLinha}>
        <Text style={styles.alunoContagemTitulo}>
          Coordenadores cadastrados
        </Text>
        <View style={styles.alunoContagemBadge}>
          <Text style={styles.alunoContagemNumero}>
            {filtrados.length}
          </Text>
        </View>
      </View>

      {carregando ? (
        <View style={styles.alunoListaVazia}>
          <ActivityIndicator
            size="large"
            color="#2563EB"
          />
        </View>
      ) : erro ? (
        <View style={styles.alunoListaVazia}>
          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>
          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtrados}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          style={styles.alunoListaNova}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 30 }}
          ListEmptyComponent={
            <View style={styles.alunoListaVazia}>
              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhum coordenador encontrado
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}
