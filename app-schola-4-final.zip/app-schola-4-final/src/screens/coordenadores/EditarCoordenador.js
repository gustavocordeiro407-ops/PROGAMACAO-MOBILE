import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarCoordenador({
  navigation,
  route
}) {

  const coordenador =
    route.params?.coordenador;


  const [nome, setNome] =
    useState(
      String(
        coordenador?.nome ?? ''
      )
    );

  const [email, setEmail] =
    useState(
      String(
        coordenador?.email ?? ''
      )
    );

  const [telefone, setTelefone] =
    useState(
      String(
        coordenador?.telefone ?? ''
      )
    );

  const [departamento, setDepartamento] =
    useState(
      String(
        coordenador?.departamento ?? ''
      )
    );

  const [dataAdmissao, setDataAdmissao] =
    useState(
      String(
        coordenador?.dataAdmissao ?? ''
      )
    );

  const [formacao, setFormacao] =
    useState(
      String(
        coordenador?.formacao ?? ''
      )
    );

  const [observacoes, setObservacoes] =
    useState(
      String(
        coordenador?.observacoes ?? ''
      )
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvar = async () => {

    if (
      nome.trim() === '' ||
      email.trim() === '' ||
      telefone.trim() === '' ||
      departamento.trim() === '' ||
      dataAdmissao.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{11}$/.test(telefone)) {

      mostrarMensagem(
        'APP Scholar',
        'O telefone deve possuir exatamente 11 números.'
      );

      return;

    }


    if (
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(
        email
      )
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Digite um e-mail válido.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_coordenador.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            id:
              coordenador.id,

            nome:
              nome.trim(),

            email:
              email.trim(),

            telefone,

            departamento:
              departamento.trim(),

            dataAdmissao,

            formacao:
              formacao.trim(),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar coordenador.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Coordenador atualizado com sucesso!'
      );


      navigation.navigate(
        'ConsultaCoordenadores'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar coordenador:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar o coordenador.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!coordenador) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Coordenador não encontrado
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar coordenador
        </Text>

        <Text style={styles.formDescricao}>
          Atualize os dados do coordenador.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados do coordenador
      </Text>


      <View style={styles.formCard}>

        <Campo label="Nome completo">

          <TextInput
            style={styles.formInput}
            value={nome}
            onChangeText={setNome}
          />

        </Campo>


        <Divisor />


        <Campo label="E-mail">

          <TextInput
            style={styles.formInput}
            value={email}
            onChangeText={setEmail}
            autoCapitalize="none"
            keyboardType="email-address"
          />

        </Campo>


        <Divisor />


        <Campo label="Telefone">

          <TextInput
            style={styles.formInput}
            value={telefone}
            onChangeText={(texto) =>
              setTelefone(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="phone-pad"
            maxLength={11}
          />

        </Campo>


        <Divisor />


        <Campo label="Departamento">

          <TextInput
            style={styles.formInput}
            value={departamento}
            onChangeText={setDepartamento}
          />

        </Campo>


        <Divisor />


        <Campo label="Data de admissão">

          <TextInput
            style={styles.formInput}
            value={dataAdmissao}
            onChangeText={(texto) =>
              setDataAdmissao(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </Campo>


        <Divisor />


        {/* FORMAÇÃO */}

        <Campo label="Formação (opcional)">

          <CampoSelecao
            tipo="formacoes"
            value={formacao}
            onChange={setFormacao}
            placeholder="Selecione a formação"
          />

        </Campo>


        <Divisor />


        <Campo label="Observações (opcional)">

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </Campo>


        <Divisor />


        <Campo label="Status">

          <TextInput
            style={styles.formInput}
            value="Ativo"
            editable={false}
          />

        </Campo>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvar}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}


function Campo({
  label,
  children
}) {

  return (

    <View style={styles.formCampo}>

      <Text style={styles.formLabel}>
        {label}
      </Text>

      {children}

    </View>

  );

}


function Divisor() {

  return (
    <View style={styles.formDivisor} />
  );

}