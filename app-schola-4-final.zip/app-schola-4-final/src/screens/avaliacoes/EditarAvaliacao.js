import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarAvaliacao({
  navigation,
  route
}) {

  const avaliacao =
    route.params?.avaliacao;


  const [aluno, setAluno] =
    useState(
      String(
        avaliacao?.aluno ?? ''
      )
    );

  const [disciplina, setDisciplina] =
    useState(
      String(
        avaliacao?.disciplina ?? ''
      )
    );

  const [tipo, setTipo] =
    useState(
      String(
        avaliacao?.tipo ?? ''
      )
    );

  const [titulo, setTitulo] =
    useState(
      String(
        avaliacao?.titulo ?? ''
      )
    );

  const [dataAvaliacao, setDataAvaliacao] =
    useState(
      String(
        avaliacao?.dataAvaliacao ?? ''
      )
    );

  const [valorMaximo, setValorMaximo] =
    useState(
      String(
        avaliacao?.valorMaximo ?? ''
      )
    );

  const [notaObtida, setNotaObtida] =
    useState(
      String(
        avaliacao?.notaObtida ?? ''
      )
    );

  const [observacoes, setObservacoes] =
    useState(
      String(
        avaliacao?.observacoes ?? ''
      )
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    tituloMsg,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${tituloMsg}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        tituloMsg,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvar = async () => {

    if (
      aluno.trim() === '' ||
      disciplina.trim() === '' ||
      tipo.trim() === '' ||
      titulo.trim() === '' ||
      dataAvaliacao.trim() === '' ||
      valorMaximo.trim() === '' ||
      notaObtida.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (
      Number(valorMaximo) <= 0 ||
      Number(notaObtida) < 0 ||
      Number(notaObtida) >
        Number(valorMaximo)
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Confira o valor máximo e a nota obtida.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_avaliacao.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            id:
              avaliacao.id,

            aluno:
              aluno.trim(),

            disciplina:
              disciplina.trim(),

            tipo:
              tipo.trim(),

            titulo:
              titulo.trim(),

            dataAvaliacao,

            valorMaximo:
              Number(valorMaximo),

            notaObtida:
              Number(notaObtida),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar avaliação.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Avaliação atualizada com sucesso!'
      );


      navigation.navigate(
        'ConsultaAvaliacoes'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar avaliação:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar a avaliação.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!avaliacao) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Avaliação não encontrada
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar avaliação
        </Text>

        <Text style={styles.formDescricao}>
          Atualize os dados da avaliação e da nota.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados da avaliação
      </Text>


      <View style={styles.formCard}>

        <Campo label="Aluno">

          <CampoSelecao
            tipo="alunos"
            value={aluno}
            onChange={setAluno}
            placeholder="Selecione o aluno"
          />

        </Campo>


        <Divisor />


        <Campo label="Disciplina">

          <CampoSelecao
            tipo="disciplinas"
            value={disciplina}
            onChange={setDisciplina}
            placeholder="Selecione a disciplina"
          />

        </Campo>


        <Divisor />


        <Campo label="Tipo de avaliação">

          <CampoSelecao
            opcoes={[
              'Prova',
              'Trabalho',
              'Atividade',
              'Seminario',
              'Projeto'
            ]}
            value={tipo}
            onChange={setTipo}
            placeholder="Selecione o tipo"
          />

        </Campo>


        <Divisor />


        <Campo label="Descrição / Título">

          <TextInput
            style={styles.formInput}
            placeholder="Ex: Prova 1º Bimestre"
            placeholderTextColor="#A3A7AF"
            value={titulo}
            onChangeText={setTitulo}
            maxLength={100}
          />

        </Campo>


        <Divisor />


        <Campo label="Data da avaliação">

          <TextInput
            style={styles.formInput}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#A3A7AF"
            value={dataAvaliacao}
            onChangeText={(texto) =>
              setDataAvaliacao(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </Campo>


        <Divisor />


        <Campo label="Valor máximo">

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 10"
            placeholderTextColor="#A3A7AF"
            value={valorMaximo}
            onChangeText={(texto) =>
              setValorMaximo(
                texto
                  .replace(
                    /[^0-9.,]/g,
                    ''
                  )
                  .replace(',', '.')
              )
            }
            keyboardType="decimal-pad"
          />

        </Campo>


        <Divisor />


        <Campo label="Nota obtida">

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 8.5"
            placeholderTextColor="#A3A7AF"
            value={notaObtida}
            onChangeText={(texto) =>
              setNotaObtida(
                texto
                  .replace(
                    /[^0-9.,]/g,
                    ''
                  )
                  .replace(',', '.')
              )
            }
            keyboardType="decimal-pad"
          />

        </Campo>


        <Divisor />


        <Campo label="Observações (opcional)">

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            placeholder="Digite observações, se necessário"
            placeholderTextColor="#A3A7AF"
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </Campo>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvar}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}


function Campo({
  label,
  children
}) {

  return (

    <View style={styles.formCampo}>

      <Text style={styles.formLabel}>
        {label}
      </Text>

      {children}

    </View>

  );

}


function Divisor() {

  return (
    <View style={styles.formDivisor} />
  );

}