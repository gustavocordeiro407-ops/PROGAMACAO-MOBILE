import React, { useState, useCallback } from 'react';
import {
  View, Text, TextInput, Pressable, FlatList,
  Alert, Platform, ActivityIndicator
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import styles from '../../styles/styles';
import API_URL from '../../services/api';

export default function ConsultarAvaliacao({ navigation }) {
  const [avaliacoes, setAvaliacoes] = useState([]);
  const [pesquisa, setPesquisa] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const carregarAvaliacoes = async () => {
    try {
      setCarregando(true);
      setErro('');

      const resposta = await fetch(
        `${API_URL}/listar_avaliacoes.php`
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar avaliações.'
        );
      }

      setAvaliacoes(resultado.dados || []);
    } catch (erro) {
      console.log('Erro ao carregar avaliações:', erro);
      setErro('Não foi possível carregar as avaliações.');
    } finally {
      setCarregando(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      carregarAvaliacoes();
    }, [])
  );

  const filtradas = avaliacoes.filter((item) => {
    const texto = pesquisa.trim().toLowerCase();

    return (
      String(item.titulo || '').toLowerCase().includes(texto) ||
      String(item.aluno || '').toLowerCase().includes(texto) ||
      String(item.disciplina || '').toLowerCase().includes(texto) ||
      String(item.tipo || '').toLowerCase().includes(texto)
    );
  });

  const inativar = async (avaliacao) => {
    try {
      const resposta = await fetch(
        `${API_URL}/inativar_avaliacao.php`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            id: avaliacao.id
          })
        }
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(resultado.mensagem);
      }

      if (Platform.OS === 'web') {
        window.alert('Avaliação inativada com sucesso!');
      } else {
        Alert.alert(
          'APP Scholar',
          'Avaliação inativada com sucesso!'
        );
      }

      await carregarAvaliacoes();
    } catch (erro) {
      if (Platform.OS === 'web') {
        window.alert(
          erro.message || 'Erro ao inativar a avaliação.'
        );
      } else {
        Alert.alert(
          'APP Scholar',
          erro.message || 'Erro ao inativar a avaliação.'
        );
      }
    }
  };

  const excluir = (avaliacao) => {
    const mensagem =
      `Deseja realmente inativar ${avaliacao.titulo || 'esta avaliação'}?`;

    if (Platform.OS === 'web') {
      if (window.confirm(mensagem)) {
        inativar(avaliacao);
      }
      return;
    }

    Alert.alert(
      'Inativar avaliação',
      mensagem,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Inativar',
          style: 'destructive',
          onPress: () => inativar(avaliacao)
        }
      ]
    );
  };

  const renderItem = ({ item }) => (
    <View style={styles.alunoNovoCard}>
      <View style={styles.alunoAvatar}>
        <Ionicons
          name="clipboard-outline"
          size={22}
          color="#2563EB"
        />
      </View>

      <View style={styles.alunoCardConteudo}>
        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.titulo || 'Avaliação sem título'}
        </Text>

        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.aluno}
        </Text>

        <View style={styles.alunoMetaLinha}>
          <Text
            style={styles.alunoMetaTexto}
            numberOfLines={1}
          >
            {item.disciplina}
          </Text>

          <Text style={styles.alunoMetaPonto}>•</Text>

          <Text style={styles.alunoMetaTexto}>
            {item.dataAvaliacao}
          </Text>
        </View>

        <Text
          style={[
            styles.alunoMetaTexto,
            { marginTop: 5 }
          ]}
        >
          Nota: {item.notaObtida || '0'} / {item.valorMaximo || '0'}
        </Text>
      </View>

      <View style={styles.alunoAcoesNovas}>
        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarAvaliacao',
              { avaliacao: item }
            )
          }
        >
          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />
        </Pressable>

        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() => excluir(item)}
        >
          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />
        </Pressable>
      </View>
    </View>
  );

  return (
    <View style={styles.alunoNovaContainer}>
      <View style={styles.alunoCabecalhoNovo}>
        <Text style={styles.alunoPequenoTitulo}>
          DESEMPENHO ACADÊMICO
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Avaliações
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte e gerencie avaliações e notas.
        </Text>
      </View>

      <View style={styles.alunoPesquisaNova}>
        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar avaliação..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />
      </View>

      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate('CadastroAvaliacao')
        }
      >
        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />
        <Text style={styles.alunoNovoBotaoTexto}>
          Nova avaliação
        </Text>
      </Pressable>

      <View style={styles.alunoContagemLinha}>
        <Text style={styles.alunoContagemTitulo}>
          Avaliações cadastradas
        </Text>

        <View style={styles.alunoContagemBadge}>
          <Text style={styles.alunoContagemNumero}>
            {filtradas.length}
          </Text>
        </View>
      </View>

      {carregando ? (
        <View style={styles.alunoListaVazia}>
          <ActivityIndicator
            size="large"
            color="#2563EB"
          />
        </View>
      ) : erro ? (
        <View style={styles.alunoListaVazia}>
          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>
          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>
        </View>
      ) : (
        <FlatList
          data={filtradas}
          keyExtractor={(item) => String(item.id)}
          renderItem={renderItem}
          style={styles.alunoListaNova}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 30 }}
          ListEmptyComponent={
            <View style={styles.alunoListaVazia}>
              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhuma avaliação encontrada
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}
