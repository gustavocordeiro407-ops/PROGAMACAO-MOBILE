import React, { useCallback, useState } from 'react';

import {
  View,
  Text,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator,
  ScrollView
} from 'react-native';

import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import API_URL from '../services/api';

const MODULOS = [
  { tipo: 'alunos', label: 'Alunos' },
  { tipo: 'professores', label: 'Professores' },
  { tipo: 'turmas', label: 'Turmas' },
  { tipo: 'cursos', label: 'Cursos' },
  { tipo: 'disciplinas', label: 'Disciplinas' },
  { tipo: 'matriculas', label: 'Matrículas' },
  { tipo: 'responsaveis', label: 'Responsáveis' },
  { tipo: 'avaliacoes', label: 'Avaliações' },
  { tipo: 'coordenadores', label: 'Coordenadores' },
  { tipo: 'boletins', label: 'Boletins' }
];

export default function GerenciarInativos() {

  const [tipo, setTipo] = useState('alunos');
  const [itens, setItens] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  const moduloAtual =
    MODULOS.find((item) => item.tipo === tipo);

  const carregar = async (tipoSelecionado = tipo) => {

    try {
      setCarregando(true);
      setErro('');

      const resposta = await fetch(
        `${API_URL}/listar_inativos.php?tipo=${encodeURIComponent(tipoSelecionado)}`
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar registros.'
        );
      }

      setItens(resultado.dados || []);

    } catch (erro) {

      console.log('Erro ao carregar inativos:', erro);

      setErro(
        erro.message ||
        'Não foi possível carregar os registros inativos.'
      );

    } finally {
      setCarregando(false);
    }
  };

  useFocusEffect(
    useCallback(() => {
      carregar(tipo);
    }, [tipo])
  );

  const executarReativacao = async (item) => {

    try {

      const resposta = await fetch(
        `${API_URL}/reativar_item.php`,
        {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            tipo,
            id: item.id
          })
        }
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(
          resultado.mensagem ||
          'Não foi possível reativar.'
        );
      }

      if (Platform.OS === 'web') {
        window.alert(
          resultado.mensagem ||
          'Registro reativado com sucesso!'
        );
      } else {
        Alert.alert(
          'APP Scholar',
          resultado.mensagem ||
          'Registro reativado com sucesso!'
        );
      }

      await carregar(tipo);

    } catch (erro) {

      if (Platform.OS === 'web') {
        window.alert(
          erro.message ||
          'Erro ao reativar o registro.'
        );
      } else {
        Alert.alert(
          'APP Scholar',
          erro.message ||
          'Erro ao reativar o registro.'
        );
      }
    }
  };

  const confirmarReativacao = (item) => {

    const mensagem =
      `Deseja reativar "${item.nome}"?`;

    if (Platform.OS === 'web') {

      if (window.confirm(mensagem)) {
        executarReativacao(item);
      }

      return;
    }

    Alert.alert(
      'Reativar registro',
      mensagem,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Reativar',
          onPress: () =>
            executarReativacao(item)
        }
      ]
    );
  };

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: '#F6F7F9',
        paddingHorizontal: 18,
        paddingTop: 22
      }}
    >
      <Text
        style={{
          color: '#2563EB',
          fontSize: 12,
          fontWeight: '700',
          letterSpacing: 1.1
        }}
      >
        GERENCIAMENTO
      </Text>

      <Text
        style={{
          color: '#171717',
          fontSize: 30,
          fontWeight: '800',
          marginTop: 6
        }}
      >
        Itens inativos
      </Text>

      <Text
        style={{
          color: '#737780',
          fontSize: 14,
          lineHeight: 20,
          marginTop: 6,
          marginBottom: 18
        }}
      >
        Consulte registros desativados e reative quando necessário.
      </Text>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{
          flexGrow: 0,
          marginBottom: 16
        }}
        contentContainerStyle={{
          paddingRight: 12
        }}
      >
        {MODULOS.map((modulo) => {

          const ativo = modulo.tipo === tipo;

          return (
            <Pressable
              key={modulo.tipo}
              onPress={() => setTipo(modulo.tipo)}
              style={{
                paddingHorizontal: 14,
                paddingVertical: 9,
                borderRadius: 999,
                marginRight: 8,
                backgroundColor:
                  ativo ? '#2563EB' : '#FFFFFF',
                borderWidth: 1,
                borderColor:
                  ativo ? '#2563EB' : '#E7E8EB'
              }}
            >
              <Text
                style={{
                  color:
                    ativo ? '#FFFFFF' : '#4B4F58',
                  fontWeight: '700',
                  fontSize: 13
                }}
              >
                {modulo.label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          marginBottom: 12
        }}
      >
        <Text
          style={{
            fontSize: 17,
            fontWeight: '700',
            color: '#171717'
          }}
        >
          {moduloAtual?.label}
        </Text>

        <View
          style={{
            marginLeft: 8,
            minWidth: 28,
            height: 28,
            paddingHorizontal: 8,
            borderRadius: 14,
            backgroundColor: '#EAF0FF',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          <Text
            style={{
              color: '#2563EB',
              fontWeight: '700'
            }}
          >
            {itens.length}
          </Text>
        </View>
      </View>

      {carregando ? (
        <View
          style={{
            paddingVertical: 60,
            alignItems: 'center'
          }}
        >
          <ActivityIndicator
            size="large"
            color="#2563EB"
          />
        </View>

      ) : erro ? (
        <View
          style={{
            backgroundColor: '#FFFFFF',
            borderWidth: 1,
            borderColor: '#E7E8EB',
            borderRadius: 16,
            padding: 20,
            alignItems: 'center'
          }}
        >
          <Ionicons
            name="cloud-offline-outline"
            size={30}
            color="#8A8F98"
          />

          <Text
            style={{
              color: '#171717',
              fontWeight: '700',
              fontSize: 16,
              marginTop: 10,
              textAlign: 'center'
            }}
          >
            Erro ao carregar
          </Text>

          <Text
            style={{
              color: '#737780',
              marginTop: 6,
              textAlign: 'center'
            }}
          >
            {erro}
          </Text>

          <Pressable
            onPress={() => carregar(tipo)}
            style={{
              marginTop: 16,
              backgroundColor: '#2563EB',
              paddingHorizontal: 16,
              paddingVertical: 10,
              borderRadius: 10
            }}
          >
            <Text
              style={{
                color: '#FFFFFF',
                fontWeight: '700'
              }}
            >
              Tentar novamente
            </Text>
          </Pressable>
        </View>

      ) : (
        <FlatList
          data={itens}
          keyExtractor={(item) =>
            String(item.id)
          }
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            paddingBottom: 30
          }}
          renderItem={({ item }) => (
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#E7E8EB',
                borderRadius: 16,
                padding: 15,
                marginBottom: 10,
                flexDirection: 'row',
                alignItems: 'center'
              }}
            >
              <View
                style={{
                  width: 42,
                  height: 42,
                  borderRadius: 13,
                  backgroundColor: '#F1F3F7',
                  alignItems: 'center',
                  justifyContent: 'center',
                  marginRight: 12
                }}
              >
                <Ionicons
                  name="archive-outline"
                  size={20}
                  color="#737780"
                />
              </View>

              <View
                style={{
                  flex: 1,
                  paddingRight: 8
                }}
              >
                <Text
                  style={{
                    color: '#171717',
                    fontSize: 15,
                    fontWeight: '700'
                  }}
                  numberOfLines={1}
                >
                  {item.nome}
                </Text>

                {item.detalhe ? (
                  <Text
                    style={{
                      color: '#737780',
                      fontSize: 13,
                      marginTop: 4
                    }}
                    numberOfLines={2}
                  >
                    {item.detalhe}
                  </Text>
                ) : null}
              </View>

              <Pressable
                onPress={() =>
                  confirmarReativacao(item)
                }
                style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: '#EAF0FF',
                  borderRadius: 10,
                  paddingHorizontal: 11,
                  paddingVertical: 9
                }}
              >
                <Ionicons
                  name="refresh-outline"
                  size={17}
                  color="#2563EB"
                />

                <Text
                  style={{
                    color: '#2563EB',
                    fontWeight: '700',
                    fontSize: 13,
                    marginLeft: 5
                  }}
                >
                  Reativar
                </Text>
              </Pressable>
            </View>
          )}
          ListEmptyComponent={
            <View
              style={{
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#E7E8EB',
                borderRadius: 16,
                padding: 30,
                alignItems: 'center'
              }}
            >
              <Ionicons
                name="checkmark-circle-outline"
                size={34}
                color="#737780"
              />

              <Text
                style={{
                  color: '#171717',
                  fontSize: 16,
                  fontWeight: '700',
                  marginTop: 10
                }}
              >
                Nenhum registro inativo
              </Text>

              <Text
                style={{
                  color: '#737780',
                  fontSize: 13,
                  marginTop: 5,
                  textAlign: 'center'
                }}
              >
                Não há itens para reativar neste módulo.
              </Text>
            </View>
          }
        />
      )}

    </View>
  );
}
