import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarMatricula({
  navigation
}) {

  const [matriculas, setMatriculas] =
    useState([]);

  const [pesquisa, setPesquisa] =
    useState('');

  const [carregando, setCarregando] =
    useState(true);

  const [erro, setErro] =
    useState('');


  const carregarMatriculas = async () => {

    try {

      setCarregando(true);
      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_matriculas.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar matrículas.'
        );

      }


      setMatriculas(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar matrículas:',
        erro
      );


      setErro(
        'Não foi possível carregar as matrículas.'
      );


    } finally {

      setCarregando(false);

    }

  };


  useFocusEffect(

    useCallback(() => {

      carregarMatriculas();

    }, [])

  );


  const matriculasFiltradas =
    matriculas.filter((matricula) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(matricula.aluno || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(matricula.ra || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(matricula.turma || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(matricula.curso || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(matricula.anoLetivo || '')
          .includes(texto)

      );

    });


  const inativarMatricula = async (
    matricula
  ) => {

    try {

      const resposta = await fetch(
        `${API_URL}/inativar_matricula.php`,
        {
          method: 'PATCH',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: matricula.id
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem
        );

      }


      if (Platform.OS === 'web') {

        window.alert(
          'Matrícula cancelada com sucesso!'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Matrícula cancelada com sucesso!'
        );

      }


      await carregarMatriculas();


    } catch (erro) {

      console.log(
        'Erro ao cancelar matrícula:',
        erro
      );


      if (Platform.OS === 'web') {

        window.alert(
          'Erro ao cancelar a matrícula.'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Erro ao cancelar a matrícula.'
        );

      }

    }

  };


  const excluirMatricula = (
    matricula
  ) => {

    const mensagem =
      `Deseja realmente cancelar a matrícula de ${matricula.aluno}?`;


    if (Platform.OS === 'web') {

      if (window.confirm(mensagem)) {

        inativarMatricula(
          matricula
        );

      }

      return;

    }


    Alert.alert(
      'Cancelar matrícula',
      mensagem,
      [
        {
          text: 'Voltar',
          style: 'cancel'
        },

        {
          text: 'Cancelar matrícula',
          style: 'destructive',

          onPress: () =>
            inativarMatricula(
              matricula
            )
        }
      ]
    );

  };


  const renderMatricula = ({ item }) => (

    <View style={styles.alunoNovoCard}>


      <View style={styles.alunoAvatar}>

        <Ionicons
          name="document-text-outline"
          size={22}
          color="#2563EB"
        />

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.aluno}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.curso} • {item.turma}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="id-card-outline"
              size={14}
              color="#8A8F98"
            />

            <Text style={styles.alunoMetaTexto}>
              {item.ra}
            </Text>

          </View>


          <Text style={styles.alunoMetaPonto}>
            •
          </Text>


          <Text style={styles.alunoMetaTexto}>
            {item.dataMatricula}
          </Text>

        </View>


        <Text
          style={[
            styles.alunoMetaTexto,
            {
              marginTop: 5
            }
          ]}
        >
          {item.anoLetivo} • {item.situacao}
        </Text>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarMatricula',
              {
                matricula: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirMatricula(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>

    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>


      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          VIDA ACADÊMICA
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Matrículas
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte e gerencie as matrículas dos alunos.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar matrícula..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroMatricula'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Nova matrícula
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Matrículas ativas
        </Text>

        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {matriculasFiltradas.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>

          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>

        </View>

      ) : (

        <FlatList
          data={matriculasFiltradas}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderMatricula}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhuma matrícula encontrada
              </Text>

            </View>

          }
        />

      )}

    </View>

  );

}