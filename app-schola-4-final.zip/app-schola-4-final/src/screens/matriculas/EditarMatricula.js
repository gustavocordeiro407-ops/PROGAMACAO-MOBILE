import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarMatricula({
  navigation,
  route
}) {

  const matricula =
    route.params?.matricula;


  const [aluno, setAluno] =
    useState(
      String(
        matricula?.aluno ?? ''
      )
    );

  const [turma, setTurma] =
    useState(
      String(
        matricula?.turma ?? ''
      )
    );

  const [curso, setCurso] =
    useState(
      String(
        matricula?.curso ?? ''
      )
    );

  const [dataMatricula, setDataMatricula] =
    useState(
      String(
        matricula?.dataMatricula ?? ''
      )
    );

  const [anoLetivo, setAnoLetivo] =
    useState(
      String(
        matricula?.anoLetivo ?? ''
      )
    );

  const [situacao, setSituacao] =
    useState(
      String(
        matricula?.situacao ?? ''
      )
    );

  const [observacoes, setObservacoes] =
    useState(
      String(
        matricula?.observacoes ?? ''
      )
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvarAlteracoes = async () => {

    if (
      aluno.trim() === '' ||
      turma.trim() === '' ||
      curso.trim() === '' ||
      dataMatricula.trim() === '' ||
      anoLetivo.trim() === '' ||
      situacao.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{4}$/.test(anoLetivo)) {

      mostrarMensagem(
        'APP Scholar',
        'O ano letivo deve possuir 4 números.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_matricula.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            id:
              matricula.id,

            aluno:
              aluno.trim(),

            turma:
              turma.trim(),

            curso:
              curso.trim(),

            dataMatricula,

            anoLetivo:
              anoLetivo.trim(),

            situacao:
              situacao.trim(),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar matrícula.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Matrícula atualizada com sucesso!'
      );


      navigation.navigate(
        'ConsultaMatriculas'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar matrícula:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar a matrícula.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!matricula) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Matrícula não encontrada
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar matrícula
        </Text>

        <Text style={styles.formDescricao}>
          Atualize os dados acadêmicos da matrícula.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados da matrícula
      </Text>


      <View style={styles.formCard}>

        {/* ALUNO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Aluno
          </Text>

          <CampoSelecao
            tipo="alunos"
            value={aluno}
            onChange={setAluno}
            placeholder="Selecione o aluno"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* TURMA */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Turma
          </Text>

          <CampoSelecao
            tipo="turmas"
            value={turma}
            onChange={setTurma}
            placeholder="Selecione a turma"
            onSelectItem={(item) => {

              setTurma(item.valor);


              if (item.curso) {

                setCurso(
                  String(item.curso)
                );

              }


              if (item.anoLetivo) {

                setAnoLetivo(
                  String(item.anoLetivo)
                );

              }

            }}
          />

        </View>


        <View style={styles.formDivisor} />


        {/* CURSO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Curso
          </Text>

          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* DATA */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Data da matrícula
          </Text>

          <TextInput
            style={styles.formInput}
            value={dataMatricula}
            onChangeText={(texto) =>
              setDataMatricula(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>


        <View style={styles.formDivisor} />


        {/* ANO LETIVO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Ano letivo
          </Text>

          <TextInput
            style={styles.formInput}
            value={anoLetivo}
            onChangeText={(texto) =>
              setAnoLetivo(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={4}
          />

        </View>


        <View style={styles.formDivisor} />


        {/* SITUAÇÃO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Situação
          </Text>

          <CampoSelecao
            opcoes={[
              'Ativa',
              'Trancada',
              'Concluida'
            ]}
            value={situacao}
            onChange={setSituacao}
            placeholder="Selecione a situação"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* OBSERVAÇÕES */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Observações
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}