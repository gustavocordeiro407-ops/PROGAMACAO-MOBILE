import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function CadastrarMatricula({
  navigation
}) {

  const [aluno, setAluno] =
    useState('');

  const [turma, setTurma] =
    useState('');

  const [curso, setCurso] =
    useState('');

  const [dataMatricula, setDataMatricula] =
    useState('');

  const [anoLetivo, setAnoLetivo] =
    useState('');

  const [situacao, setSituacao] =
    useState('Ativa');

  const [observacoes, setObservacoes] =
    useState('');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const formatarData = (texto) => {

    let numeros =
      texto.replace(/[^0-9]/g, '');


    if (numeros.length > 8) {

      numeros =
        numeros.substring(0, 8);

    }


    if (numeros.length <= 2) {

      return numeros;

    }


    if (numeros.length <= 4) {

      return (
        `${numeros.substring(0, 2)}/` +
        `${numeros.substring(2)}`
      );

    }


    return (
      `${numeros.substring(0, 2)}/` +
      `${numeros.substring(2, 4)}/` +
      `${numeros.substring(4, 8)}`
    );

  };


  const salvarMatricula = async () => {

    if (
      aluno.trim() === '' ||
      turma.trim() === '' ||
      curso.trim() === '' ||
      dataMatricula.trim() === '' ||
      anoLetivo.trim() === '' ||
      situacao.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (!/^\d{4}$/.test(anoLetivo)) {

      mostrarMensagem(
        'APP Scholar',
        'O ano letivo deve possuir 4 números.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/cadastrar_matricula.php`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({

            aluno:
              aluno.trim(),

            turma:
              turma.trim(),

            curso:
              curso.trim(),

            dataMatricula,

            anoLetivo:
              anoLetivo.trim(),

            situacao:
              situacao.trim(),

            observacoes:
              observacoes.trim()

          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao cadastrar matrícula.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Matrícula cadastrada com sucesso!'
      );


      navigation.navigate(
        'ConsultaMatriculas'
      );


    } catch (erro) {

      console.log(
        'Erro ao cadastrar matrícula:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível cadastrar a matrícula.'
      );


    } finally {

      setSalvando(false);

    }

  };


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          NOVA MATRÍCULA
        </Text>

        <Text style={styles.formTitulo}>
          Nova matrícula
        </Text>

        <Text style={styles.formDescricao}>
          Preencha os dados acadêmicos para realizar uma nova matrícula.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados da matrícula
      </Text>


      <View style={styles.formCard}>

        {/* ALUNO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Aluno
          </Text>

          <CampoSelecao
            tipo="alunos"
            value={aluno}
            onChange={setAluno}
            placeholder="Selecione o aluno"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* TURMA */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Turma
          </Text>

          <CampoSelecao
            tipo="turmas"
            value={turma}
            onChange={setTurma}
            placeholder="Selecione a turma"
            onSelectItem={(item) => {

              setTurma(item.valor);


              if (item.curso) {

                setCurso(
                  String(item.curso)
                );

              }


              if (item.anoLetivo) {

                setAnoLetivo(
                  String(item.anoLetivo)
                );

              }

            }}
          />

        </View>


        <View style={styles.formDivisor} />


        {/* CURSO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Curso
          </Text>

          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* DATA */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Data da matrícula
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="DD/MM/AAAA"
            placeholderTextColor="#A3A7AF"
            value={dataMatricula}
            onChangeText={(texto) =>
              setDataMatricula(
                formatarData(texto)
              )
            }
            keyboardType="numeric"
            maxLength={10}
          />

        </View>


        <View style={styles.formDivisor} />


        {/* ANO LETIVO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Ano letivo
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 2026"
            placeholderTextColor="#A3A7AF"
            value={anoLetivo}
            onChangeText={(texto) =>
              setAnoLetivo(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
            maxLength={4}
          />

        </View>


        <View style={styles.formDivisor} />


        {/* SITUAÇÃO */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Situação
          </Text>

          <CampoSelecao
            opcoes={[
              'Ativa',
              'Trancada',
              'Concluida'
            ]}
            value={situacao}
            onChange={setSituacao}
            placeholder="Selecione a situação"
          />

        </View>


        <View style={styles.formDivisor} />


        {/* OBSERVAÇÕES */}

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Observações
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            placeholder="Observações opcionais"
            placeholderTextColor="#A3A7AF"
            value={observacoes}
            onChangeText={setObservacoes}
            multiline
            maxLength={255}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarMatricula}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar matrícula'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}