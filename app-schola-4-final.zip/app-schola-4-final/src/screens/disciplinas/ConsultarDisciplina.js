import React, {
  useState,
  useCallback
} from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  FlatList,
  Alert,
  Platform,
  ActivityIndicator
} from 'react-native';

import {
  useFocusEffect
} from '@react-navigation/native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';


export default function ConsultarDisciplina({
  navigation
}) {

  const [disciplinas, setDisciplinas] =
    useState([]);

  const [pesquisa, setPesquisa] =
    useState('');

  const [carregando, setCarregando] =
    useState(true);

  const [erro, setErro] =
    useState('');


  const carregarDisciplinas = async () => {

    try {

      setCarregando(true);
      setErro('');


      const resposta = await fetch(
        `${API_URL}/listar_disciplinas.php`
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar disciplinas.'
        );

      }


      setDisciplinas(
        resultado.dados || []
      );


    } catch (erro) {

      console.log(
        'Erro ao carregar disciplinas:',
        erro
      );


      setErro(
        'Não foi possível carregar as disciplinas do banco.'
      );


    } finally {

      setCarregando(false);

    }

  };


  useFocusEffect(

    useCallback(() => {

      carregarDisciplinas();

    }, [])

  );


  const disciplinasFiltradas =
    disciplinas.filter((disciplina) => {

      const texto =
        pesquisa
          .trim()
          .toLowerCase();


      return (

        String(disciplina.nome || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(disciplina.codigo || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(disciplina.curso || '')
          .toLowerCase()
          .includes(texto)

        ||

        String(disciplina.professor || '')
          .toLowerCase()
          .includes(texto)

      );

    });


  const inativarDisciplina = async (
    disciplina
  ) => {

    try {

      const resposta = await fetch(
        `${API_URL}/inativar_disciplina.php`,
        {
          method: 'PATCH',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: disciplina.id
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem
        );

      }


      if (Platform.OS === 'web') {

        window.alert(
          'Disciplina inativada com sucesso!'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Disciplina inativada com sucesso!'
        );

      }


      await carregarDisciplinas();


    } catch (erro) {

      console.log(
        'Erro ao inativar disciplina:',
        erro
      );


      if (Platform.OS === 'web') {

        window.alert(
          'Erro ao inativar a disciplina.'
        );

      } else {

        Alert.alert(
          'APP Scholar',
          'Erro ao inativar a disciplina.'
        );

      }

    }

  };


  const excluirDisciplina = (
    disciplina
  ) => {

    const mensagem =
      `Deseja realmente inativar a disciplina ${disciplina.nome}?`;


    if (Platform.OS === 'web') {

      if (window.confirm(mensagem)) {

        inativarDisciplina(
          disciplina
        );

      }

      return;

    }


    Alert.alert(
      'Inativar disciplina',
      mensagem,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },

        {
          text: 'Inativar',
          style: 'destructive',

          onPress: () =>
            inativarDisciplina(
              disciplina
            )
        }
      ]
    );

  };


  const renderDisciplina = ({ item }) => (

    <View style={styles.alunoNovoCard}>


      <View style={styles.alunoAvatar}>

        <Ionicons
          name="book-outline"
          size={22}
          color="#2563EB"
        />

      </View>


      <View style={styles.alunoCardConteudo}>

        <Text
          style={styles.alunoNomeNovo}
          numberOfLines={1}
        >
          {item.nome}
        </Text>


        <Text
          style={styles.alunoCursoNovo}
          numberOfLines={1}
        >
          {item.codigo ||
            'Código não informado'}
        </Text>


        <View style={styles.alunoMetaLinha}>

          <View style={styles.alunoMetaItem}>

            <Ionicons
              name="school-outline"
              size={14}
              color="#8A8F98"
            />

            <Text
              style={styles.alunoMetaTexto}
              numberOfLines={1}
            >
              {item.curso ||
                'Curso não informado'}
            </Text>

          </View>


          <Text style={styles.alunoMetaPonto}>
            •
          </Text>


          <Text style={styles.alunoMetaTexto}>
            {item.cargaHoraria}h
          </Text>

        </View>


        <Text
          style={[
            styles.alunoMetaTexto,
            {
              marginTop: 5
            }
          ]}
          numberOfLines={1}
        >
          Professor: {item.professor ||
            'Não informado'}
        </Text>

      </View>


      <View style={styles.alunoAcoesNovas}>

        <Pressable
          style={styles.alunoBotaoEditar}
          onPress={() =>
            navigation.navigate(
              'EditarDisciplina',
              {
                disciplina: item
              }
            )
          }
        >

          <Ionicons
            name="pencil-outline"
            size={18}
            color="#2563EB"
          />

        </Pressable>


        <Pressable
          style={styles.alunoBotaoExcluir}
          onPress={() =>
            excluirDisciplina(item)
          }
        >

          <Ionicons
            name="trash-outline"
            size={18}
            color="#DC2626"
          />

        </Pressable>

      </View>

    </View>

  );


  return (

    <View style={styles.alunoNovaContainer}>


      <View style={styles.alunoCabecalhoNovo}>

        <Text style={styles.alunoPequenoTitulo}>
          GRADE ACADÊMICA
        </Text>

        <Text style={styles.alunoTituloNovo}>
          Disciplinas
        </Text>

        <Text style={styles.alunoDescricaoNova}>
          Consulte e gerencie as disciplinas cadastradas.
        </Text>

      </View>


      <View style={styles.alunoPesquisaNova}>

        <Ionicons
          name="search-outline"
          size={20}
          color="#8A8F98"
        />

        <TextInput
          style={styles.alunoPesquisaInput}
          placeholder="Pesquisar disciplina..."
          placeholderTextColor="#A3A7AF"
          value={pesquisa}
          onChangeText={setPesquisa}
        />

      </View>


      <Pressable
        style={styles.alunoNovoBotao}
        onPress={() =>
          navigation.navigate(
            'CadastroDisciplina'
          )
        }
      >

        <Ionicons
          name="add"
          size={20}
          color="#FFFFFF"
        />

        <Text style={styles.alunoNovoBotaoTexto}>
          Nova disciplina
        </Text>

      </Pressable>


      <View style={styles.alunoContagemLinha}>

        <Text style={styles.alunoContagemTitulo}>
          Disciplinas cadastradas
        </Text>

        <View style={styles.alunoContagemBadge}>

          <Text style={styles.alunoContagemNumero}>
            {disciplinasFiltradas.length}
          </Text>

        </View>

      </View>


      {carregando ? (

        <View style={styles.alunoListaVazia}>

          <ActivityIndicator
            size="large"
            color="#2563EB"
          />

        </View>

      ) : erro ? (

        <View style={styles.alunoListaVazia}>

          <Text style={styles.alunoListaVaziaTitulo}>
            Erro na conexão
          </Text>

          <Text style={styles.alunoListaVaziaTexto}>
            {erro}
          </Text>

        </View>

      ) : (

        <FlatList
          data={disciplinasFiltradas}

          keyExtractor={(item) =>
            String(item.id)
          }

          renderItem={renderDisciplina}

          style={styles.alunoListaNova}

          showsVerticalScrollIndicator={false}

          contentContainerStyle={{
            paddingBottom: 30
          }}

          ListEmptyComponent={

            <View style={styles.alunoListaVazia}>

              <Text style={styles.alunoListaVaziaTitulo}>
                Nenhuma disciplina encontrada
              </Text>

            </View>

          }
        />

      )}

    </View>

  );

}