import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function EditarDisciplina({
  navigation,
  route
}) {

  const disciplina =
    route.params?.disciplina;


  const [nome, setNome] =
    useState(
      String(disciplina?.nome ?? '')
    );

  const [codigo, setCodigo] =
    useState(
      String(disciplina?.codigo ?? '')
    );

  const [curso, setCurso] =
    useState(
      String(disciplina?.curso ?? '')
    );

  const [descricao, setDescricao] =
    useState(
      String(disciplina?.descricao ?? '')
    );

  const [cargaHoraria, setCargaHoraria] =
    useState(
      String(
        disciplina?.cargaHoraria ?? ''
      )
    );

  const [professor, setProfessor] =
    useState(
      String(
        disciplina?.professor ?? ''
      )
    );

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarAlteracoes = async () => {

    if (
      nome.trim() === '' ||
      codigo.trim() === '' ||
      curso.trim() === '' ||
      descricao.trim() === '' ||
      cargaHoraria.trim() === '' ||
      professor.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (Number(cargaHoraria) <= 0) {

      mostrarMensagem(
        'APP Scholar',
        'A carga horária deve ser maior que zero.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/editar_disciplina.php`,
        {
          method: 'PUT',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            id: disciplina.id,
            nome: nome.trim(),
            codigo: codigo.trim(),
            curso: curso.trim(),
            descricao:
              descricao.trim(),
            cargaHoraria:
              Number(cargaHoraria),
            professor:
              professor.trim()
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao atualizar disciplina.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Disciplina atualizada com sucesso!'
      );


      navigation.navigate(
        'ConsultaDisciplinas'
      );


    } catch (erro) {

      console.log(
        'Erro ao editar disciplina:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível atualizar a disciplina.'
      );


    } finally {

      setSalvando(false);

    }

  };


  if (!disciplina) {

    return (

      <View style={styles.formErroContainer}>

        <Text style={styles.formErroTitulo}>
          Disciplina não encontrada
        </Text>

      </View>

    );

  }


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          EDIÇÃO
        </Text>

        <Text style={styles.formTitulo}>
          Editar disciplina
        </Text>

        <Text style={styles.formDescricao}>
          Atualize as informações da disciplina e salve.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados da disciplina
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome da disciplina
          </Text>

          <TextInput
            style={styles.formInput}
            value={nome}
            onChangeText={setNome}
            maxLength={100}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Código
          </Text>

          <TextInput
            style={styles.formInput}
            value={codigo}
            onChangeText={setCodigo}
            maxLength={20}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Curso
          </Text>

          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Descrição
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            value={descricao}
            onChangeText={setDescricao}
            multiline
            maxLength={255}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Carga horária
          </Text>

          <TextInput
            style={styles.formInput}
            value={cargaHoraria}
            onChangeText={(texto) =>
              setCargaHoraria(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Professor responsável
          </Text>

          <CampoSelecao
            tipo="professores"
            value={professor}
            onChange={setProfessor}
            placeholder="Selecione o professor"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Status
          </Text>

          <TextInput
            style={styles.formInput}
            value="Ativo"
            editable={false}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarAlteracoes}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}