import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  Pressable,
  ScrollView,
  Alert,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../../styles/styles';

import API_URL from '../../services/api';

import CampoSelecao from '../../components/CampoSelecao';


export default function CadastrarDisciplina({
  navigation
}) {

  const [nome, setNome] =
    useState('');

  const [codigo, setCodigo] =
    useState('');

  const [curso, setCurso] =
    useState('');

  const [descricao, setDescricao] =
    useState('');

  const [cargaHoraria, setCargaHoraria] =
    useState('');

  const [professor, setProfessor] =
    useState('');

  const [salvando, setSalvando] =
    useState(false);


  const mostrarMensagem = (
    titulo,
    mensagem
  ) => {

    if (Platform.OS === 'web') {

      window.alert(
        `${titulo}\n\n${mensagem}`
      );

    } else {

      Alert.alert(
        titulo,
        mensagem
      );

    }

  };


  const salvarDisciplina = async () => {

    if (
      nome.trim() === '' ||
      codigo.trim() === '' ||
      curso.trim() === '' ||
      descricao.trim() === '' ||
      cargaHoraria.trim() === '' ||
      professor.trim() === ''
    ) {

      mostrarMensagem(
        'APP Scholar',
        'Preencha todos os campos obrigatórios.'
      );

      return;

    }


    if (Number(cargaHoraria) <= 0) {

      mostrarMensagem(
        'APP Scholar',
        'A carga horária deve ser maior que zero.'
      );

      return;

    }


    try {

      setSalvando(true);


      const resposta = await fetch(
        `${API_URL}/cadastrar_disciplina.php`,
        {
          method: 'POST',

          headers: {
            'Content-Type':
              'application/json'
          },

          body: JSON.stringify({
            nome: nome.trim(),
            codigo: codigo.trim(),
            curso: curso.trim(),
            descricao:
              descricao.trim(),
            cargaHoraria:
              Number(cargaHoraria),
            professor:
              professor.trim()
          })
        }
      );


      const resultado =
        await resposta.json();


      if (!resultado.sucesso) {

        throw new Error(
          resultado.mensagem ||
          'Erro ao cadastrar disciplina.'
        );

      }


      mostrarMensagem(
        'APP Scholar',
        'Disciplina cadastrada com sucesso!'
      );


      navigation.navigate(
        'ConsultaDisciplinas'
      );


    } catch (erro) {

      console.log(
        'Erro ao cadastrar disciplina:',
        erro
      );


      mostrarMensagem(
        'APP Scholar',
        erro.message ||
        'Não foi possível cadastrar a disciplina.'
      );


    } finally {

      setSalvando(false);

    }

  };


  return (

    <ScrollView
      contentContainerStyle={
        styles.formNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      <View style={styles.formCabecalho}>

        <Text style={styles.formPequenoTitulo}>
          NOVO CADASTRO
        </Text>

        <Text style={styles.formTitulo}>
          Nova disciplina
        </Text>

        <Text style={styles.formDescricao}>
          Preencha as informações para cadastrar uma nova disciplina.
        </Text>

      </View>


      <Text style={styles.formTituloSecao}>
        Dados da disciplina
      </Text>


      <View style={styles.formCard}>

        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Nome da disciplina
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: Lógica de Programação"
            placeholderTextColor="#A3A7AF"
            value={nome}
            onChangeText={setNome}
            maxLength={100}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Código da disciplina
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: LOG101"
            placeholderTextColor="#A3A7AF"
            value={codigo}
            onChangeText={setCodigo}
            maxLength={20}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Curso
          </Text>

          <CampoSelecao
            tipo="cursos"
            value={curso}
            onChange={setCurso}
            placeholder="Selecione o curso"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Descrição
          </Text>

          <TextInput
            style={[
              styles.formInput,
              {
                minHeight: 90,
                textAlignVertical: 'top'
              }
            ]}
            placeholder="Digite a descrição da disciplina"
            placeholderTextColor="#A3A7AF"
            value={descricao}
            onChangeText={setDescricao}
            multiline
            maxLength={255}
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Carga horária
          </Text>

          <TextInput
            style={styles.formInput}
            placeholder="Ex: 80"
            placeholderTextColor="#A3A7AF"
            value={cargaHoraria}
            onChangeText={(texto) =>
              setCargaHoraria(
                texto.replace(
                  /[^0-9]/g,
                  ''
                )
              )
            }
            keyboardType="numeric"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Professor responsável
          </Text>

          <CampoSelecao
            tipo="professores"
            value={professor}
            onChange={setProfessor}
            placeholder="Selecione o professor"
          />

        </View>


        <View style={styles.formDivisor} />


        <View style={styles.formCampo}>

          <Text style={styles.formLabel}>
            Status
          </Text>

          <TextInput
            style={styles.formInput}
            value="Ativo"
            editable={false}
          />

        </View>

      </View>


      <View style={styles.formBotoesLinha}>

        <Pressable
          style={styles.formBotaoSecundario}
          onPress={() =>
            navigation.goBack()
          }
          disabled={salvando}
        >

          <Text style={styles.formBotaoSecundarioTexto}>
            Cancelar
          </Text>

        </Pressable>


        <Pressable
          style={[
            styles.formBotaoPrincipal,

            salvando && {
              opacity: 0.6
            }
          ]}
          onPress={salvarDisciplina}
          disabled={salvando}
        >

          <Ionicons
            name="checkmark"
            size={19}
            color="#FFFFFF"
          />

          <Text style={styles.formBotaoPrincipalTexto}>
            {salvando
              ? 'Salvando...'
              : 'Salvar disciplina'}
          </Text>

        </Pressable>

      </View>

    </ScrollView>

  );

}