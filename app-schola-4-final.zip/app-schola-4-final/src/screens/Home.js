import React from 'react';

import {
  View,
  Text,
  Pressable,
  ScrollView
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';

import styles from '../styles/styles';


export default function Home({ navigation }) {

  const principais = [
    {
      titulo: 'Alunos',
      descricao: 'Cadastros e informações',
      icone: 'people-outline',
      rota: 'ConsultaAlunos'
    },
    {
      titulo: 'Professores',
      descricao: 'Equipe acadêmica',
      icone: 'person-outline',
      rota: 'ConsultaProfessores'
    },
    {
      titulo: 'Turmas',
      descricao: 'Organização das classes',
      icone: 'school-outline',
      rota: 'ConsultaTurmas'
    },
    {
      titulo: 'Cursos',
      descricao: 'Cursos disponíveis',
      icone: 'layers-outline',
      rota: 'ConsultaCursos'
    }
  ];


  const outros = [
    {
      titulo: 'Disciplinas',
      icone: 'book-outline',
      rota: 'ConsultaDisciplinas'
    },
    {
      titulo: 'Matrículas',
      icone: 'clipboard-outline',
      rota: 'ConsultaMatriculas'
    },
    {
      titulo: 'Responsáveis',
      icone: 'people-circle-outline',
      rota: 'ConsultaResponsaveis'
    },
    {
      titulo: 'Avaliações',
      icone: 'document-text-outline',
      rota: 'ConsultaAvaliacoes'
    },
    {
      titulo: 'Coordenadores',
      icone: 'briefcase-outline',
      rota: 'ConsultaCoordenadores'
    },
    {
      titulo: 'Boletins',
      icone: 'bar-chart-outline',
      rota: 'ConsultaBoletins'
    }
  ];


  return (

    <ScrollView
      contentContainerStyle={
        styles.homeNovaContainer
      }
      showsVerticalScrollIndicator={false}
    >

      {/* CABEÇALHO */}

      <View style={styles.homeCabecalho}>

        <View style={styles.homeMarcaLinha}>

          <View style={styles.homeLogoNova}>

            <Ionicons
              name="school"
              size={26}
              color="#2563EB"
            />

          </View>


          <View>

            <Text style={styles.homeMarca}>
              APP Scholar
            </Text>

            <Text style={styles.homeMarcaSub}>
              Sistema acadêmico
            </Text>

          </View>

        </View>


        <Pressable
          style={styles.homeInfoBotao}
          onPress={() =>
            navigation.navigate('Sobre')
          }
        >

          <Ionicons
            name="information-circle-outline"
            size={25}
            color="#525866"
          />

        </Pressable>

      </View>


      {/* APRESENTAÇÃO */}

      <View style={styles.homeApresentacao}>

        <Text style={styles.homePequenoTitulo}>
          PAINEL ACADÊMICO
        </Text>

        <Text style={styles.homeTituloNovo}>
          Tudo da escola,{'\n'}
          em um só lugar.
        </Text>

        <Text style={styles.homeDescricaoNova}>
          Acesse rapidamente alunos, professores,
          turmas e outras informações acadêmicas.
        </Text>

      </View>


      {/* PRINCIPAIS */}

      <Text style={styles.homeTituloSecao}>
        Gerenciamento
      </Text>


      <View style={styles.homeGrid}>

        {principais.map((item) => (

          <Pressable
            key={item.titulo}
            style={styles.homeCard}
            onPress={() =>
              navigation.navigate(item.rota)
            }
          >

            <View style={styles.homeCardTopo}>

              <View style={styles.homeCardIcone}>

                <Ionicons
                  name={item.icone}
                  size={23}
                  color="#2563EB"
                />

              </View>


              <Ionicons
                name="arrow-forward-outline"
                size={18}
                color="#A0A4AC"
              />

            </View>


            <Text style={styles.homeCardTitulo}>
              {item.titulo}
            </Text>


            <Text style={styles.homeCardDescricao}>
              {item.descricao}
            </Text>

          </Pressable>

        ))}

      </View>


      {/* OUTROS MÓDULOS */}

      <Text style={styles.homeTituloSecao}>
        Outros módulos
      </Text>


      <View style={styles.homeLista}>

        {outros.map((item, index) => (

          <Pressable
            key={item.titulo}
            style={[
              styles.homeListaItem,

              index !== outros.length - 1 &&
              styles.homeListaItemBorda
            ]}
            onPress={() =>
              navigation.navigate(item.rota)
            }
          >

            <View style={styles.homeListaEsquerda}>

              <View style={styles.homeListaIcone}>

                <Ionicons
                  name={item.icone}
                  size={20}
                  color="#525866"
                />

              </View>


              <Text style={styles.homeListaTexto}>
                {item.titulo}
              </Text>

            </View>


            <Ionicons
              name="chevron-forward"
              size={19}
              color="#A0A4AC"
            />

          </Pressable>

        ))}

      </View>


      {/* ITENS INATIVOS */}

      <Text
        style={[
          styles.homeTituloSecao,
          {
            marginTop: 24
          }
        ]}
      >
        Administração
      </Text>


      <Pressable
        onPress={() =>
          navigation.navigate(
            'GerenciarInativos'
          )
        }
        style={{
          backgroundColor: '#FFFFFF',
          borderWidth: 1,
          borderColor: '#E7E8EB',
          borderRadius: 16,
          padding: 16,
          flexDirection: 'row',
          alignItems: 'center'
        }}
      >

        <View
          style={{
            width: 42,
            height: 42,
            borderRadius: 13,
            backgroundColor: '#EAF0FF',
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 12
          }}
        >

          <Ionicons
            name="refresh-outline"
            size={21}
            color="#2563EB"
          />

        </View>


        <View style={{ flex: 1 }}>

          <Text
            style={{
              fontSize: 15,
              fontWeight: '700',
              color: '#171717'
            }}
          >
            Itens inativos
          </Text>

          <Text
            style={{
              marginTop: 3,
              fontSize: 13,
              color: '#737780'
            }}
          >
            Consulte e reative registros
          </Text>

        </View>


        <Ionicons
          name="chevron-forward"
          size={19}
          color="#A0A4AC"
        />

      </Pressable>


      {/* RODAPÉ */}

      <Text
        style={[
          styles.homeRodape,
          {
            marginTop: 26
          }
        ]}
      >
        APP Scholar • Sistema Acadêmico
      </Text>

    </ScrollView>

  );

}