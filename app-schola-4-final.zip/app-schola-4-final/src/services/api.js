const API_URL =
  'https://appscholar.alwaysdata.net';

export default API_URL;