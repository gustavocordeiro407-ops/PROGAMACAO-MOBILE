import React, { useMemo, useState } from 'react';

import {
  View,
  Text,
  Pressable,
  Modal,
  FlatList,
  TextInput,
  ActivityIndicator,
  Platform
} from 'react-native';

import { Ionicons } from '@expo/vector-icons';
import API_URL from '../services/api';

export default function CampoSelecao({
  label,
  value,
  onChange,
  tipo,
  opcoes = [],
  placeholder = 'Selecionar',
  onSelectItem
}) {

  const [visivel, setVisivel] = useState(false);
  const [busca, setBusca] = useState('');
  const [itensBanco, setItensBanco] = useState([]);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState('');

  const carregarBanco = async () => {

    if (!tipo) return;

    try {
      setCarregando(true);
      setErro('');

      const resposta = await fetch(
        `${API_URL}/listar_opcoes.php?tipo=${encodeURIComponent(tipo)}`
      );

      const resultado = await resposta.json();

      if (!resultado.sucesso) {
        throw new Error(
          resultado.mensagem ||
          'Erro ao carregar opções.'
        );
      }

      setItensBanco(resultado.dados || []);

    } catch (erro) {
      console.log('Erro ao carregar opções:', erro);
      setErro(
        erro.message ||
        'Não foi possível carregar as opções.'
      );
    } finally {
      setCarregando(false);
    }
  };

  const abrir = async () => {
    setBusca('');
    setVisivel(true);

    if (tipo && itensBanco.length === 0) {
      await carregarBanco();
    }
  };

  const itens = useMemo(() => {

    if (tipo) return itensBanco;

    return opcoes.map((opcao) => {
      if (typeof opcao === 'string') {
        return {
          valor: opcao,
          label: opcao
        };
      }

      return {
        valor: opcao.valor ?? opcao.value ?? opcao.label,
        label: opcao.label ?? opcao.valor ?? opcao.value,
        ...opcao
      };
    });

  }, [tipo, itensBanco, opcoes]);

  const itensFiltrados =
    itens.filter((item) => {

      const texto =
        busca.trim().toLowerCase();

      return (
        String(item.label || '')
          .toLowerCase()
          .includes(texto)
        ||
        String(item.valor || '')
          .toLowerCase()
          .includes(texto)
      );
    });

  const selecionar = (item) => {

    onChange(String(item.valor ?? ''));

    if (onSelectItem) {
      onSelectItem(item);
    }

    setVisivel(false);
  };

  return (
    <View style={{ marginVertical: 2 }}>

      {label ? (
        <Text
          style={{
            fontSize: 13,
            fontWeight: '600',
            color: '#4B4F58',
            marginBottom: 8
          }}
        >
          {label}
        </Text>
      ) : null}

      <Pressable
        onPress={abrir}
        style={{
          minHeight: 48,
          borderWidth: 1,
          borderColor: '#E7E8EB',
          borderRadius: 12,
          paddingHorizontal: 14,
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-between',
          backgroundColor: '#FFFFFF'
        }}
      >
        <Text
          style={{
            flex: 1,
            fontSize: 15,
            color: value ? '#171717' : '#A3A7AF'
          }}
          numberOfLines={1}
        >
          {value || placeholder}
        </Text>

        <Ionicons
          name="chevron-down"
          size={18}
          color="#8A8F98"
        />
      </Pressable>

      <Modal
        visible={visivel}
        transparent
        animationType="fade"
        onRequestClose={() => setVisivel(false)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: 'rgba(0,0,0,0.38)',
            justifyContent:
              Platform.OS === 'web'
                ? 'center'
                : 'flex-end',
            alignItems: 'center'
          }}
        >
          <View
            style={{
              width:
                Platform.OS === 'web'
                  ? '92%'
                  : '100%',
              maxWidth: 520,
              maxHeight: '78%',
              backgroundColor: '#F6F7F9',
              borderRadius:
                Platform.OS === 'web'
                  ? 24
                  : 0,
              borderTopLeftRadius: 24,
              borderTopRightRadius: 24,
              padding: 18
            }}
          >
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                marginBottom: 14
              }}
            >
              <Text
                style={{
                  fontSize: 20,
                  fontWeight: '700',
                  color: '#171717'
                }}
              >
                {label || 'Selecionar'}
              </Text>

              <Pressable
                onPress={() => setVisivel(false)}
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 19,
                  backgroundColor: '#FFFFFF',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}
              >
                <Ionicons
                  name="close"
                  size={21}
                  color="#4B4F58"
                />
              </Pressable>
            </View>

            <View
              style={{
                minHeight: 46,
                backgroundColor: '#FFFFFF',
                borderWidth: 1,
                borderColor: '#E7E8EB',
                borderRadius: 12,
                flexDirection: 'row',
                alignItems: 'center',
                paddingHorizontal: 12,
                marginBottom: 12
              }}
            >
              <Ionicons
                name="search-outline"
                size={19}
                color="#8A8F98"
              />

              <TextInput
                style={{
                  flex: 1,
                  minHeight: 44,
                  paddingHorizontal: 10,
                  fontSize: 15,
                  color: '#171717'
                }}
                placeholder="Pesquisar..."
                placeholderTextColor="#A3A7AF"
                value={busca}
                onChangeText={setBusca}
              />
            </View>

            {carregando ? (
              <View
                style={{
                  paddingVertical: 40,
                  alignItems: 'center'
                }}
              >
                <ActivityIndicator
                  size="large"
                  color="#2563EB"
                />
              </View>

            ) : erro ? (
              <View
                style={{
                  paddingVertical: 28,
                  alignItems: 'center'
                }}
              >
                <Text
                  style={{
                    color: '#DC2626',
                    textAlign: 'center',
                    marginBottom: 14
                  }}
                >
                  {erro}
                </Text>

                <Pressable
                  onPress={carregarBanco}
                  style={{
                    backgroundColor: '#2563EB',
                    paddingHorizontal: 16,
                    paddingVertical: 10,
                    borderRadius: 10
                  }}
                >
                  <Text
                    style={{
                      color: '#FFFFFF',
                      fontWeight: '700'
                    }}
                  >
                    Tentar novamente
                  </Text>
                </Pressable>
              </View>

            ) : (
              <FlatList
                data={itensFiltrados}
                keyExtractor={(item, index) =>
                  `${String(item.valor)}-${index}`
                }
                keyboardShouldPersistTaps="handled"
                renderItem={({ item }) => (
                  <Pressable
                    onPress={() => selecionar(item)}
                    style={{
                      backgroundColor: '#FFFFFF',
                      borderWidth: 1,
                      borderColor:
                        value === String(item.valor)
                          ? '#2563EB'
                          : '#E7E8EB',
                      borderRadius: 12,
                      paddingHorizontal: 14,
                      paddingVertical: 13,
                      marginBottom: 8
                    }}
                  >
                    <Text
                      style={{
                        color: '#171717',
                        fontSize: 15,
                        fontWeight:
                          value === String(item.valor)
                            ? '700'
                            : '500'
                      }}
                    >
                      {item.label}
                    </Text>
                  </Pressable>
                )}
                ListEmptyComponent={
                  <View
                    style={{
                      paddingVertical: 30,
                      alignItems: 'center'
                    }}
                  >
                    <Text style={{ color: '#737780' }}>
                      Nenhuma opção encontrada.
                    </Text>
                  </View>
                }
              />
            )}

          </View>
        </View>
      </Modal>

    </View>
  );
}
