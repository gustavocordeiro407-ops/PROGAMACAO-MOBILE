  import React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import Home from './src/screens/Home';
import Sobre from './src/screens/Sobre';

import GerenciarInativos from './src/screens/GerenciarInativos';

import CadastrarAluno from './src/screens/alunos/CadastrarAluno';
import ConsultarAluno from './src/screens/alunos/ConsultarAluno';
import EditarAluno from './src/screens/alunos/EditarAluno';

import CadastrarProfessor from './src/screens/professores/CadastrarProfessor';
import ConsultarProfessor from './src/screens/professores/ConsultarProfessor';
import EditarProfessor from './src/screens/professores/EditarProfessor';

import CadastrarTurma from './src/screens/turmas/CadastrarTurma';
import ConsultarTurma from './src/screens/turmas/ConsultarTurma';
import EditarTurma from './src/screens/turmas/EditarTurma';

import CadastrarCurso from './src/screens/cursos/CadastrarCurso';
import ConsultarCurso from './src/screens/cursos/ConsultarCurso';
import EditarCurso from './src/screens/cursos/EditarCurso';

import CadastrarDisciplina from './src/screens/disciplinas/CadastrarDisciplina';
import ConsultarDisciplina from './src/screens/disciplinas/ConsultarDisciplina';
import EditarDisciplina from './src/screens/disciplinas/EditarDisciplina';

import CadastrarMatricula from './src/screens/matriculas/CadastrarMatricula';
import ConsultarMatricula from './src/screens/matriculas/ConsultarMatricula';
import EditarMatricula from './src/screens/matriculas/EditarMatricula';

import CadastrarResponsavel from './src/screens/responsaveis/CadastrarResponsavel';
import ConsultarResponsavel from './src/screens/responsaveis/ConsultarResponsavel';
import EditarResponsavel from './src/screens/responsaveis/EditarResponsavel';

import CadastrarAvaliacao from './src/screens/avaliacoes/CadastrarAvaliacao';
import ConsultarAvaliacao from './src/screens/avaliacoes/ConsultarAvaliacao';
import EditarAvaliacao from './src/screens/avaliacoes/EditarAvaliacao';

import CadastrarCoordenador from './src/screens/coordenadores/CadastrarCoordenador';
import ConsultarCoordenador from './src/screens/coordenadores/ConsultarCoordenador';
import EditarCoordenador from './src/screens/coordenadores/EditarCoordenador';

import CadastrarBoletim from './src/screens/boletins/CadastrarBoletim';
import ConsultarBoletim from './src/screens/boletins/ConsultarBoletim';
import EditarBoletim from './src/screens/boletins/EditarBoletim';


const Stack = createNativeStackNavigator();


export default function App() {

  return (

    <NavigationContainer>

      <Stack.Navigator
        initialRouteName="Home"
      >

        <Stack.Screen
          name="Home"
          component={Home}
          options={{
            title: 'APP Scholar'
          }}
        />

        <Stack.Screen
          name="Sobre"
          component={Sobre}
          options={{
            title: 'Sobre'
          }}
        />

        <Stack.Screen
          name="GerenciarInativos"
          component={GerenciarInativos}
          options={{
            title: 'Itens inativos'
          }}
        />


        {/* ALUNOS */}

        <Stack.Screen
          name="ConsultaAlunos"
          component={ConsultarAluno}
          options={{
            title: 'Alunos'
          }}
        />

        <Stack.Screen
          name="CadastroAluno"
          component={CadastrarAluno}
          options={{
            title: 'Cadastro de Aluno'
          }}
        />

        <Stack.Screen
          name="EditarAluno"
          component={EditarAluno}
          options={{
            title: 'Editar Aluno'
          }}
        />


        {/* PROFESSORES */}

        <Stack.Screen
          name="ConsultaProfessores"
          component={ConsultarProfessor}
          options={{
            title: 'Professores'
          }}
        />

        <Stack.Screen
          name="CadastroProfessor"
          component={CadastrarProfessor}
          options={{
            title: 'Cadastro de Professor'
          }}
        />

        <Stack.Screen
          name="EditarProfessor"
          component={EditarProfessor}
          options={{
            title: 'Editar Professor'
          }}
        />


        {/* TURMAS */}

        <Stack.Screen
          name="ConsultaTurmas"
          component={ConsultarTurma}
          options={{
            title: 'Turmas'
          }}
        />

        <Stack.Screen
          name="CadastroTurma"
          component={CadastrarTurma}
          options={{
            title: 'Cadastro de Turma'
          }}
        />

        <Stack.Screen
          name="EditarTurma"
          component={EditarTurma}
          options={{
            title: 'Editar Turma'
          }}
        />


        {/* CURSOS */}

        <Stack.Screen
          name="ConsultaCursos"
          component={ConsultarCurso}
          options={{
            title: 'Cursos'
          }}
        />

        <Stack.Screen
          name="CadastroCurso"
          component={CadastrarCurso}
          options={{
            title: 'Cadastro de Curso'
          }}
        />

        <Stack.Screen
          name="EditarCurso"
          component={EditarCurso}
          options={{
            title: 'Editar Curso'
          }}
        />


        {/* DISCIPLINAS */}

        <Stack.Screen
          name="ConsultaDisciplinas"
          component={ConsultarDisciplina}
          options={{
            title: 'Disciplinas'
          }}
        />

        <Stack.Screen
          name="CadastroDisciplina"
          component={CadastrarDisciplina}
          options={{
            title: 'Cadastro de Disciplina'
          }}
        />

        <Stack.Screen
          name="EditarDisciplina"
          component={EditarDisciplina}
          options={{
            title: 'Editar Disciplina'
          }}
        />


        {/* MATRÍCULAS */}

        <Stack.Screen
          name="ConsultaMatriculas"
          component={ConsultarMatricula}
          options={{
            title: 'Matrículas'
          }}
        />

        <Stack.Screen
          name="CadastroMatricula"
          component={CadastrarMatricula}
          options={{
            title: 'Cadastro de Matrícula'
          }}
        />

        <Stack.Screen
          name="EditarMatricula"
          component={EditarMatricula}
          options={{
            title: 'Editar Matrícula'
          }}
        />


        {/* RESPONSÁVEIS */}

        <Stack.Screen
          name="ConsultaResponsaveis"
          component={ConsultarResponsavel}
          options={{
            title: 'Responsáveis'
          }}
        />

        <Stack.Screen
          name="CadastroResponsavel"
          component={CadastrarResponsavel}
          options={{
            title: 'Cadastro de Responsável'
          }}
        />

        <Stack.Screen
          name="EditarResponsavel"
          component={EditarResponsavel}
          options={{
            title: 'Editar Responsável'
          }}
        />


        {/* AVALIAÇÕES */}

        <Stack.Screen
          name="ConsultaAvaliacoes"
          component={ConsultarAvaliacao}
          options={{
            title: 'Avaliações'
          }}
        />

        <Stack.Screen
          name="CadastroAvaliacao"
          component={CadastrarAvaliacao}
          options={{
            title: 'Cadastro de Avaliação'
          }}
        />

        <Stack.Screen
          name="EditarAvaliacao"
          component={EditarAvaliacao}
          options={{
            title: 'Editar Avaliação'
          }}
        />


        {/* COORDENADORES */}

        <Stack.Screen
          name="ConsultaCoordenadores"
          component={ConsultarCoordenador}
          options={{
            title: 'Coordenadores'
          }}
        />

        <Stack.Screen
          name="CadastroCoordenador"
          component={CadastrarCoordenador}
          options={{
            title: 'Cadastro de Coordenador'
          }}
        />

        <Stack.Screen
          name="EditarCoordenador"
          component={EditarCoordenador}
          options={{
            title: 'Editar Coordenador'
          }}
        />


        {/* BOLETINS */}

        <Stack.Screen
          name="ConsultaBoletins"
          component={ConsultarBoletim}
          options={{
            title: 'Boletins'
          }}
        />

        <Stack.Screen
          name="CadastroBoletim"
          component={CadastrarBoletim}
          options={{
            title: 'Cadastro de Boletim'
          }}
        />

        <Stack.Screen
          name="EditarBoletim"
          component={EditarBoletim}
          options={{
            title: 'Editar Boletim'
          }}
        />

      </Stack.Navigator>

    </NavigationContainer>

  );

}